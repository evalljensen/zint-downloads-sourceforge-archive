/* code.c - Handles Code 11, 39, 39+ and 93 */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* In version 0.5 this file was 1,553 lines long! */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "common.h"

#define NASET	"0123456789-"
static char *C11Table[11] = {"111121", "211121", "121121", "221111", "112121", "212111", "122111",
	"111221", "211211", "211111", "112111"};

#define ALSET	"0123456789-:<"
static char *C13Table[13] = {"211111", "111121", "111211", "111221", "112111", "112121", "112211",
	"121111", "121121", "122111", "211121", "211211", "212111"};
	
#define TCSET	"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd"
static char *C39Table[43] = { "1112212111", "2112111121", "1122111121", "2122111111", "1112211121",
	"2112211111", "1122211111", "1112112121", "2112112111", "1122112111", "2111121121",
	"1121121121", "2121121111", "1111221121", "2111221111", "1121221111", "1111122121",
	"2111122111", "1121122111", "1111222111", "2111111221", "1121111221", "2121111211",
	"1111211221", "2111211211", "1121211211", "1111112221", "2111112211", "1121112211",
	"1111212211", "2211111121", "1221111121", "2221111111", "1211211121", "2211211111",
	"1221211111", "1211112121", "2211112111", "1221112111", "1212121111", "1212111211",
	"1211121211", "1112121211"};

/* This table from http://www.barcodeisland.com */
static char *EC39Ctrl[128] = {"%U", "$A", "$B", "$C", "$D", "$E", "$F", "$G", "$H", "$I", "$J", "$K",
	"$L", "$M", "$N", "$O", "$P", "$Q", "$R", "$S", "$T", "$U", "$V", "$W", "$X", "$Y", "$Z",
	"%A", "%B", "%C", "%D", "%E", " ", "/A", "/B", "/C", "/D", "/E", "/F", "/G", "/H", "/I", "/J",
	"/K", "/L", "/M", "/N", "/O", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "/Z", "%F",
	"%G", "%H", "%I", "%J", "%V", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
	"N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "%K", "%L", "%M", "%N", "%O",
	"%W", "+A", "+B", "+C", "+D", "+E", "+F", "+G", "+H", "+I", "+J", "+K", "+L", "+M", "+N", "+O",
	"+P", "+Q", "+R", "+S", "+T", "+U", "+V", "+W", "+X", "+Y", "+Z", "%P", "%Q", "%R", "%S", "%T"};

static char *C93Ctrl[128] = {"bU", "aA", "aB", "aC", "aD", "aE", "aF", "aG", "aH", "aI", "aJ", "aK",
	"aL", "aM", "aN", "aO", "aP", "aQ", "aR", "aS", "aT", "aU", "aV", "aW", "aX", "aY", "aZ",
	"bA", "bB", "bC", "bD", "bE", " ", "cA", "cB", "cC", "cD", "cE", "cF", "cG", "cH", "cI", "cJ",
	"cK", "cL", "cM", "cN", "cO", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "cZ", "bF",
	"bG", "bH", "bI", "bJ", "bV", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
	"N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "bK", "bL", "bM", "bN", "bO",
	"bW", "dA", "dB", "dC", "dD", "dE", "dF", "dG", "dH", "dI", "dJ", "dK", "dL", "dM", "dN", "dO",
	"dP", "dQ", "dR", "dS", "dT", "dU", "dV", "dW", "dX", "dY", "dZ", "bP", "bQ", "bR", "bS", "bT"};

static char *C93Table[47] = {"131112", "111213", "111312", "111411", "121113", "121212", "121311",
	"111114", "131211", "141111", "211113", "211212", "211311", "221112", "221211", "231111",
	"112113", "112212", "112311", "122112", "132111", "111123", "111222", "111321", "121122",
	"131121", "212112", "212211", "211122", "211221", "221121", "222111", "112122", "112221",
	"122121", "123111", "121131", "311112", "311211", "321111", "112131", "113121", "211131",
	"121221", "312111", "311121", "122211"};

/* *********************** CODE 11 ******************** */

void code_11(char source[], char dest[])
{ /* Code 11 */

	unsigned int i;
	int h, c_digit, c_weight, c_count, k_digit, k_weight, k_count;
	int weight[1000];

	if(strlen(source) > 80) {
		fprintf(stderr, "error: code 11 input too long\n");
		exit(TRUE);
	}
	is_sane(NASET, source);
	c_weight = 1;
	c_count = 0;
	k_weight = 1;
	k_count = 0;

	/* start character */
	concat (dest, "112211");

	/* Draw main body of barcode */
	for(i = 0; i < strlen(source); i++) {
		lookup(NASET, C11Table, source[i], dest);
		weight[i] = ctoi(source[i]);
	}

	/* Calculate C checksum */
	for(h = (strlen(source) - 1); h >= 0; h--) {
		c_count += (c_weight * weight[h]);
		c_weight++;

		if(c_weight > 10) {
			c_weight = 1;
		}
	}
	c_digit = c_count%11;

	/* Draw C checksum */
	lookup(NASET, C11Table, itoc(c_digit), dest);
	weight[strlen(source)] = c_digit;

	/* Calculate K checksum */
	for(h = strlen(source); h >= 0; h--) {
		k_count += (k_weight * weight[h]);
		k_weight++;

		if(k_weight > 9) {
			k_weight = 1;
		}
	}
	k_digit = k_count%11;

	/* Draw K checksum */
	lookup(NASET, C11Table, itoc(k_digit), dest);

	printf("CODE11 check digits '%c%c'\n", itoc(c_digit), itoc(k_digit));

	/* Stop character */
	concat (dest, "11221");
}

void code_13(char source[], char dest[])
{ /* A variation of Code 13 - this function is left something of an easter egg because I
	don't know if the Code 13 specification was ever seen outside of Intermec's labs.
	It was developed for the Intermec Ruby Wand hand held scanner. This code gives
	an approximation to the 'standard' and is here just for the hell of it! */
	
	int weight, sum, check, i;
	char check_char;
	
	if(strlen(source) > 80) {
		fprintf(stderr, "error: code 13 input too long\n");
		exit(TRUE);
	}
	is_sane(ALSET, source);
	
	/* start character */
	concat (dest, "221111");
	
	sum = 0;
	weight = 1;
	
	/* Draw main body of barcode */
	for(i = 0; i < strlen(source); i++) {
		lookup(ALSET, C13Table, source[i], dest);
		if((source[i] != ':') && (source[i] != '<')) {
			sum += weight * ctoi(source[i]);
		} else {
			switch (source[i]) {
				case ':': sum += weight * 11; break;
				case '<': sum += weight * 12; break;
			}
		}
		if(weight == 1) {
			weight = 2;
		} else {
			weight = 1;
		}
	}
	
	/* check digit */
	check = sum % 13;
	if (check < 11) {
		check_char = itoc(check);
	} else {
		if(check == 11) { check_char = ':'; }
		if(check == 12) { check_char = '<'; }
	}
	
	lookup(NASET, C11Table, check_char, dest);
	
	printf("CODE13: check character %c\n", check_char);
	
	/* stop character */
	concat (dest, "22111");
}

/* *************** CODE 39 ********************** */

void c39(char source[], char dest[])
{ /* The basic Code 39 barcode system consisting of simple substitution */
	unsigned int i;

	if(strlen(source) > 45) {
		fprintf(stderr, "error: Code 39 input too long\n");
		exit(TRUE);
	}
	to_upper(source);
	is_sane(TCSET , source);

	/* Start character */
	concat(dest, "1211212111");

	for(i = 0; i <= strlen(source); i++) {
		lookup(TCSET, C39Table, source[i], dest);
	}
	/* Stop character */
	concat (dest, "121121211");
}

void pharmazentral(char source[], char dest[])
{ /* Pharmazentralnumber (PZN) */
	
	int i;
	unsigned int h, count, check_digit;

	count = 0;
	h = strlen(source);
	is_sane(NESET, source);
	if(h != 6) { fprintf(stderr, "Invalid length PZN '%s'\n", source);
		exit(TRUE);
	}
	
	for (i = 0; i < h; i++)
	{
		count += (i + 2) * ctoi(source[i]);
	}

	for(i = h + 1; i >= 1; i--)
	{
		source[i] = source[i - 1];
	}
	source[0] = '-';
	
	check_digit = count%11;
	if (check_digit == 11) { check_digit = 0; }
	source[h + 1] = itoc(check_digit);
	source[h + 2] = '\0';
	c39(source, dest);
	printf("PZN Check Digit %d\n", check_digit);

}


/* ************** EXTENDED CODE 39 *************** */

void ec39(char source[], char dest[])
{ /* An extension to the Code 39 system which supports extra characters including lower case */

	char buffer[100];
	unsigned int i;
	strcpy(buffer, "");
	int ascii_value;

	if(strlen(source) > 45) {
		/* only stops strings which are far too long - actual length of the barcode
		depends on the type of data being encoded - if it's too long it's picked up
		by c39() */
		fprintf(stderr, "error: Code 39e input too long\n");
		exit(TRUE);
	}
	prescan(source);
	/* Creates a buffer string and places control characters into it */
	for(i = 0; i < strlen(source); i++) {
		ascii_value = source[i];
		concat(buffer, EC39Ctrl[ascii_value]);
	}

	/* Then sends the buffer to the C39 function */
	c39(source, dest);
}

/* ******************** CODE 93 ******************* */

void c93(char source[], char dest[])
{ /* Code 93 is an advancement on Code 39 and the definition is a lot tighter */

  /* TCSET includes the extra characters a, b, c and d to represent Code 93 specific
     shift characters 1, 2, 3 and 4 respectively. These characters are never used by
     c39() and ec39() */

	unsigned int i;
	int h, weight, c, k, values[100];
	char buffer[100], temp[2];
	char set_copy[] = TCSET;
	strcpy(buffer, "");
	int ascii_value;

	if(strlen(source) > 45) {
		/* This stops rediculously long input - the actual length of the barcode
		depends on the type of data */
		fprintf(stderr, "error: Code 93 input too long\n");
		exit(TRUE);
	}
	prescan(source);
	/* Start character */
	concat(dest, "111141");

	/* Message Content */
	for(i = 0; i < strlen(source); i++) {
		ascii_value = source[i];
		concat(buffer, C93Ctrl[ascii_value]);
	}

	/* Now we can check the true length of the barcode */
	if(strlen(buffer) > 45) {
		fprintf(stderr, "error: Code 93 input too long\n");
		exit(TRUE);
	}
	
	for(i = 0; i < strlen(buffer); i++) {
		values[i] = posn(TCSET, buffer[i]);
	}

	/* Putting the data into dest[] is not done until after check digits are calculated */

	/* Check digit C */
	printf("CODE93 Check Digits '"); /* Characters output from c93_check */

	c = 0;
	weight = 1;
	for(h = strlen(buffer) - 1; h >= 0; h--)
	{
		c += values[h] * weight;
		weight ++;
		if(weight == 21)
		{
			weight = 1;
		}
	}
	c = c % 47;

	/* Because concat() requires a string as its second argument the check digit is converted
	   to a character which is then put in temp[] before being added to buffer[] - its
	   a bit long winded but avoids putting yet another function into common.c */

	values[strlen(buffer)] = c;
	temp[0] = set_copy[c];
	temp[1] = '\0';
	printf("%s", temp);
	concat(buffer, temp);

	/* Check digit K */
	k = 0;
	weight = 1;
	for(h = strlen(buffer) - 1; h >= 0; h--)
	{
		k += values[h] * weight;
		weight ++;
		if(weight == 16)
		{
			weight = 1;
		}
	}
	k = k % 47;
	temp[0] = set_copy[k];
	temp[1] = '\0';
	printf("%s", temp);
	concat(buffer, temp);

	printf("'\n");

	for(i = 0; i < strlen(buffer); i++) {
		lookup(TCSET, C93Table, buffer[i], dest);
	}

	/* Stop character */
	concat(dest, "1111411");
}

void logmars(char source[], char dest[])
{ /* LOGMARS is a Code 39 variant used by the US Department of Defence */
	unsigned int i;
	unsigned int counter;
	char check_digit;

	to_upper(source);
	if(strlen(source) > 45) {
		fprintf(stderr, "error: LOGMARS input too long\n");
		exit(TRUE);
	}
	is_sane(TCSET , source);

	/* Start character */
	concat(dest, "1211212111");

	for(i = 0; i <= strlen(source); i++) {
		lookup(TCSET, C39Table, source[i], dest);
		counter += posn(TCSET, source[i]);
	}
	counter = counter % 43;
	if(counter < 10) {
		check_digit = itoc(counter);
	} else {
		if(counter < 36) {
			check_digit = (counter - 10) + 'A';
		} else {
			switch(counter) {
				case 36: check_digit = '-'; break;
				case 37: check_digit = '.'; break;
				case 38: check_digit = ' '; break;
				case 39: check_digit = '$'; break;
				case 40: check_digit = '/'; break;
				case 41: check_digit = '+'; break;
				case 42: check_digit = 37; break;
			}
		}
	}
	lookup(TCSET, C39Table, check_digit, dest);
	
	/* Display a space check digit as _, otherwise it looks like an error */
	if(check_digit == ' ') {
		check_digit = '_';
	}
	
	printf("LOGMARS check digit %c\n", check_digit);
	
	/* Stop character */
	concat (dest, "121121211");
	
	/* LOGMARS uses wider 'wide' bars than normal Code 39 */
	for(i = 0; i < strlen(dest); i++) {
		if(dest[i] == '2') {
			dest[i] = '3';
		}
	}
}
