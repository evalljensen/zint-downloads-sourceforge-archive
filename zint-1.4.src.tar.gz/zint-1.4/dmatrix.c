/* dmatrix.c - Handles Data Matrix 2-D symbology (IEC16022 ecc 200) */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This file is a hacked-up copy of:
 * IEC16022 bar code generation by
 * Adrian Kennard, Andrews & Arnold Ltd
 * with help from Cliff Hones on the RS coding
 *
 * (c) 2004 Adrian Kennard, Andrews & Arnold Ltd
 * (c) 2006 Stefan Schmidt <stefan@datenfreihafen.org>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* The original version of this code is available at:
   http://www.datenfreihafen.org/projects/iec16022.html */

#define IEC16022_VERSION "0.2"

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <malloc.h>
#include <errno.h>
#include "dm200.h"
#include "common.h"

 // simple checked response malloc
void *safemalloc(int n)
{
	void *p = malloc(n);
	if (!p) {
		fprintf(stderr, "Malloc(%d) failed\n", n);
		exit(1);
	}
	return p;
}

void dmatrix(struct symbol_struct *symbol, char *barcode, char *eccstr, char *infile, char *size)
{
	int W = 0, H = 0;
	int ecc = 0;
	int barcodelen = 0;
	char *encoding = 0;
	int len = 0, maxlen = 0, ecclen = 0;
	unsigned char *grid = 0;
	
	if (strlen(barcode) == 0) {		// read from file
		FILE *f = fopen(infile, "rb");
		barcode = safemalloc(4001);
		if (!f) {
			perror(infile);
			exit(1);
		}
		barcodelen = fread(barcode, 1, 4000, f);
		if (barcodelen < 0) {
			perror(infile);
			exit(1);
		}
		barcode[barcodelen] = 0;	// null terminate anyway
		fclose(f);
	} else
		barcodelen = strlen(barcode);
		if(barcodelen > 780) {
			fprintf(stderr, "Input text too long\n");
			exit(1);
		}
	// check parameters
	if (strlen(size) != 0) {
		char *x = strchr(size, 'x');
		W = atoi(size);
		if (x)
			H = atoi(x + 1);
		if (!H)
			W = H;
	}
	if (eccstr)
		ecc = atoi(eccstr);
	if (W & 1) {		// odd size
		if (W != H || W < 9 || W > 49) {
			fprintf(stderr, "Invalid size %dx%d\n", W, H);
			exit(1);
		}
		if (!eccstr) {
			if (W >= 17)
				ecc = 140;
			else if (W >= 13)
				ecc = 100;
			else if (W >= 11)
				ecc = 80;
			else
				ecc = 0;
		}
		if (ecc && ecc != 50 && ecc != 80 && ecc != 100 && ecc != 140 ||
		    ecc == 50 && W < 11 || ecc == 80 && W < 13 || ecc == 100
		    && W < 13 || ecc == 140 && W < 17) {
			fprintf(stderr, "ECC%03d invalid for %dx%d\n", ecc, W,
				H);
			exit(1);
		}

	} else if (W) {		// even size
		if (W < H) {
			int t = W;
			W = H;
			H = t;
		}
		if (!eccstr)
			ecc = 200;
		if (ecc != 200) {
			fprintf(stderr, "ECC%03d invalid for %dx%d\n", ecc, W,
				H);
			exit(1);
		}
	}

	else {			// auto size
		if (!eccstr)
			// default is even sizes only unless explicit ecc set to force odd
			// sizes
			ecc = 200;
	}

	// processing stamps
	if ((W & 1) || ecc < 200) {	// odd sizes
		fprintf(stderr, "Not done odd sizes yet, sorry\n");
	} else {		// even sizes
		grid =
		    iec16022ecc200(&W, &H, &encoding, barcodelen, barcode, &len,
				   &maxlen, &ecclen);
	}

	// output
	if (!grid || !W) {
		fprintf(stderr, "No barcode produced\n");
		exit(1);
	}
	int y;
	/*for (y = H - 1; y >= 0; y--) {
		int x;
		for (x = 0; x < W; x++)
			printf("%c",
				grid[W * y + x] ? '*' : ' ');
		printf("\n");
	}*/
	
	symbol->symbology_type = MATRIX;
	symbol->no_of_rows = H;
	symbol->max_width = W;
	
	for(y = H - 1; y >= 0; y--) {
		int x;
		for(x = 0; x < W; x++) {
			if(grid[W * y + x]) {
				symbol->encoded_data[(H - y) - 1][x] = '1'; }
			else {
				symbol->encoded_data[(H - y) - 1][x] = '0'; }
		}
	}
}
