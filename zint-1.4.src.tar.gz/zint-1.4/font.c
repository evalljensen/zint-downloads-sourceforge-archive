/* font.c - Output encoded data as font-friendly text */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"

void font_plot(struct symbol_struct *symbol)
{
	int i, j, char_value;

	if(symbol->symbology_type != MATRIX) {
		for(j = 0; j < symbol->no_of_rows; j++) {
			for(i = 0; i < symbol->max_width; i += 4) {
				char_value = 0;
				if(symbol->encoded_data[j][i] == '1') { char_value += 8; }
				if(symbol->encoded_data[j][i + 1] == '1') { char_value += 4; }
				if(symbol->encoded_data[j][i + 2] == '1') { char_value += 2; }
				if(symbol->encoded_data[j][i + 3] == '1') { char_value += 1; }
		
				printf("%c", itoc(char_value));
			}
			printf("\n");
		}
	} else {
		for(j = 0; j < symbol->no_of_rows; j += 2) {
			for(i = 0; i < symbol->max_width; i += 2) {
				char_value = 0;
				if(symbol->encoded_data[j][i] == '1') { char_value += 1; }
				if(symbol->encoded_data[j][i + 1] == '1') { char_value += 2; }
				if(symbol->encoded_data[j + 1][i] == '1') { char_value += 4; }
				if(symbol->encoded_data[j + 1][i + 1] == '1') { char_value += 8; }
		
				printf("%c", (char_value + 'A'));
			}
			printf("\n");
		}
	}
}
