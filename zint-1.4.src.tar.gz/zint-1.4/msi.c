/* msi.c - Handles MSI/Plessey with various check options */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "common.h"

static char *MSITable[10] = {"12121212", "12121221", "12122112", "12122121", "12211212", "12211221",
	"12212112", "12212121", "21121212", "21121221"};

void msi_plessey(char source[], char dest[])
{ /* Plain MSI Plessey - does not calculate any check character */

	unsigned int i;

	if(strlen(source) > 55) { /* No Entry Stack Smashers! */
		fprintf(stderr, "Plessey input too long\n");
		exit(TRUE);
	}
	is_sane(NESET, source);

	/* start character */
	concat (dest, "21");

	for(i = 0; i <= strlen(source); i++)
	{
		lookup(NESET, MSITable, source[i], dest);
	}

	/* Stop character */
	concat (dest, "121");
}

void msi_plessey_mod10(char source[], char dest[])
{ /* MSI Plessey with Modulo 10 check digit - algorithm from Barcode Island
	 http://www.barcodeisland.com/ */

	unsigned int i, wright, dau, pedwar, pump;
	char un[200], tri[200];

	if(strlen(source) > 55) { /* No Entry Stack Smashers! */
		fprintf(stderr, "Plessey input too long\n");
		exit(TRUE);
	}
	is_sane(NESET, source);

	/* start character */
	concat (dest, "21");

	/* draw data section */
	for(i = 0; i < strlen(source); i++)
	{
		lookup(NESET, MSITable, source[i], dest);
	}

	/* caluculate check digit */
	wright = 0;
	if((strlen(source)%2) == 0)
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	else
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	un[wright] = '\0';

	dau = atoi(un);
	dau *= 2;

	sprintf(tri,"%d",dau);

	pedwar = 0;
	for(i = 0; i < strlen(tri); i++)
	{
		pedwar += ctoi(tri[i]);
	}


	if((strlen(source)%2) == 0)
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}
	else
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}

	pump = (10 - pedwar%10);
	if(pump == 10)
	{
		pump = 0;
	}

	/* draw check digit */
	printf("MSI check digit '%c'\n", itoc(pump));
	lookup(NESET, MSITable, itoc(pump), dest);

	/* Stop character */
	concat (dest, "121");
}

void msi_plessey_mod1010(char source[], char dest[])
{ /* MSI Plessey with two Modulo 10 check digits - algorithm from
     Barcode Island http://www.barcodeisland.com/ */

	unsigned int i, wright, dau, pedwar, pump, chwech;
	char un[200], tri[200];
	
	if(strlen(source) > 55) { /* No Entry Stack Smashers! */
		fprintf(stderr, "Plessey input too long\n");
		exit(TRUE);
	}
	is_sane(NESET, source);

	/* start character */
	concat (dest, "21");

	/* draw data section */
	for(i = 0; i < strlen(source); i++)
	{
		lookup(NESET, MSITable, source[i], dest);
	}

	/* calculate first check digit */
	wright = 0;
	if((strlen(source)%2) == 0)
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	else
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	un[wright] = '\0';

	dau = atoi(un);
	dau *= 2;

	sprintf(tri,"%d",dau);

	pedwar = 0;
	for(i = 0; i < strlen(tri); i++)
	{
		pedwar += ctoi(tri[i]);
	}


	if((strlen(source)%2) == 0)
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}
	else
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}

	pump = (10 - pedwar%10);
	if(pump == 10)
	{
		pump = 0;
	}

	/* calculate second check digit */
	wright = 0;
	if((strlen(source)%2) == 0)
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	else
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	un[wright] = itoc(pump);
	wright++;
	un[wright] = '\0';

	dau = atoi(un);
	dau *= 2;

	sprintf(tri,"%d",dau);

	pedwar = 0;
	for(i = 0; i < strlen(tri); i++)
	{
		pedwar += ctoi(tri[i]);
	}


	if((strlen(source)%2) == 0)
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}
	else
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}

	chwech = (10 - pedwar%10);
	if(chwech == 10)
	{
		chwech = 0;
	}

	/* Draw check digits */
	printf("MSI check digits '%c%c'\n", itoc(pump), itoc(chwech));
	lookup(NESET, MSITable, itoc(pump), dest);
	lookup(NESET, MSITable, itoc(chwech), dest);

	/* Stop character */
	concat (dest, "121");
}


void msi_plessey_mod11(char source[], char dest[])
{
	/* Calculate a Modulo 11 check digit using the system discussed on Wikipedia - 
	see http://en.wikipedia.org/wiki/Talk:MSI_Barcode */
	/* uses the IBM weight system */
	
	int i, weight, x, check;

	if(strlen(source) > 55) { /* No Entry Stack Smashers! */
		fprintf(stderr, "Plessey input too long\n");
		exit(TRUE);
	}
	is_sane(NESET, source);
	
	/* start character */
	concat (dest, "21");
	
	/* draw data section */
	for(i = 0; i < strlen(source); i++)
	{
		lookup(NESET, MSITable, source[i], dest);
	}

	/* calculate check digit */
	x = 0;
	weight = 2;
	for(i = (strlen(source) - 1); i >= 0; i--) {
		x += weight * ctoi(source[i]);
		weight++;
		if(weight > 7) {
			weight = 2;
		}
	}
	
	check = (11 - (x % 11)) % 11;
	if(check == 10) {
		lookup(NESET, MSITable, '1', dest);
		lookup(NESET, MSITable, '0', dest);
	} else {
		lookup(NESET, MSITable, itoc(check), dest);
	}
	printf("MSI check digit %d\n", check);
	
	/* stop character */
	concat (dest, "121");
}

void msi_plessey_mod1110(char source[], char dest[])
{
	/* Combining the Barcode Island and Wikipedia code */
	/* Verified against http://www.bokai.com/BarcodeJSP/applet/BarcodeSampleApplet.htm */
	/* Weighted using the IBM system */
	
	int i, weight, x, check, wright, dau, pedwar, pump;
	char un[200], tri[200];

	if(strlen(source) > 55) { /* No Entry Stack Smashers! */
		fprintf(stderr, "Plessey input too long\n");
		exit(TRUE);
	}
	is_sane(NESET, source);
	
	/* start character */
	concat (dest, "21");
	
	/* draw data section */
	for(i = 0; i < strlen(source); i++)
	{
		lookup(NESET, MSITable, source[i], dest);
	}

	/* calculate first (mod 11) digit */
	wright = strlen(source);
	x = 0;
	weight = 2;
	for(i = (strlen(source) - 1); i >= 0; i--) {
		x += weight * ctoi(source[i]);
		weight++;
		if(weight > 7) {
			weight = 2;
		}
	}
	
	check = (11 - (x % 11)) % 11;
	if(check == 10) {
		lookup(NESET, MSITable, '1', dest);
		lookup(NESET, MSITable, '0', dest);
		source[wright] = '1';
		source[wright + 1] = '0';
		source[wright + 2] = '\0';
	} else {
		lookup(NESET, MSITable, itoc(check), dest);
		source[wright] = itoc(check);
		source[wright + 1] = '\0';
	}
	
	/* caluculate second (mod 10) check digit */
	wright = 0;
	if((strlen(source)%2) == 0)
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	else
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			un[wright] = source[i];
			wright ++;
		}
	}
	un[wright] = '\0';

	dau = atoi(un);
	dau *= 2;

	sprintf(tri,"%d",dau);

	pedwar = 0;
	for(i = 0; i < strlen(tri); i++)
	{
		pedwar += ctoi(tri[i]);
	}


	if((strlen(source)%2) == 0)
	{
		for(i = 0; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}
	else
	{
		for(i = 1; i < strlen(source); i+=2)
		{
			pedwar += ctoi(source[i]);
		}
	}

	pump = (10 - pedwar%10);
	if(pump == 10)
	{
		pump = 0;
	}

	/* draw check digit */
	printf("MSI check digits '%d/%c'\n", check, itoc(pump));
	lookup(NESET, MSITable, itoc(pump), dest);

	/* stop character */
	concat (dest, "121");
}
