/* pdf417.c - Handles PDF417 stacked symbology */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart
    Portions Copyright (C) 2004 Grandzebu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdlib.h>
#include <errno.h>
#include "pdf417.h"
#include "common.h"

/* Adapted from "Code barre PDF 417 / PDF 417 barcode" v2.5.0 which is Copyright (C) 2004 (Grandzebu)
   Three figure numbers in comments give the location of command equivalents in the
   original Visual Basic source code file pdf417.frm
   The original code can be downloaded from http://grandzebu.net/index.php
   this code retains some original (French) procedure and variable names to ease conversion */

int liste[2][1000]; /* global - okay, so I got _almost_ everything local! */

/* 866 */
int quelmode(char codeascii)
{
	int mode;
	mode = BYT;
	
	if((codeascii >= ' ') && (codeascii <= '~')) { mode = TEX; }
	if(codeascii == '\t') { mode = TEX; }
	if(codeascii == '\n') { mode = TEX; }
	if(codeascii == 13) { mode = TEX; }
	if((codeascii >= '0') && (codeascii <= '9')) { mode = NUM; }
	/* 876 */
	return mode;
}

/* 844 */
void regroupe(int *indexliste)
{
	int i, j;
	
	/* bring together same type blocks */
	if(*(indexliste) > 1) {
		i = 1;
		while(i < *(indexliste)) {
			if(liste[1][i - 1] == liste[1][i]) {
				/* bring together */
				liste[0][i - 1] = liste[0][i - 1] + liste[0][i];
				j = i + 1;
				
				/* decreace the list */
				while(j < *(indexliste)) {
					liste[0][j - 1] = liste[0][j];
					liste[1][j - 1] = liste[1][j];
					j++;
				}
				*(indexliste) = *(indexliste) - 1;
				i--;
			}
			i++;
		}
	}
	/* 865 */
}

/* 478 */
void pdfsmooth(int *indexliste)
{
	int i, this, last, next, length;
	
	for(i = 0; i < *(indexliste); i++) {
		this = liste[1][i];
		length = liste[0][i];
		if(i != 0) { last = liste[1][i - 1]; } else { last = FALSE; }
		if(i != *(indexliste) - 1) { next = liste[1][i + 1]; } else { next = FALSE; }
		
		if(this == NUM) {
			if(i == 0) { /* first block */
				if(*(indexliste) > 0) { /* and there are others */
					if((next == TEX) && (length < 8)) { liste[1][i] = TEX;}
					if((next == BYT) && (length == 1)) { liste[1][i] = BYT; }
				}
			} else {
				if(i == *(indexliste) - 1) { /* last block */
					if((last == TEX) && (length < 7)) { liste[1][i] = TEX; }
					if((last == BYT) && (length == 1)) { liste[1][i] = BYT; }
				} else { /* not first or last block */
					if(((last == BYT) && (next == BYT)) && (length < 4)) { liste[1][i] = BYT; }
					if(((last == BYT) && (next == TEX)) && (length < 4)) { liste[1][i] = TEX; }
					if(((last == TEX) && (next == BYT)) && (length < 5)) { liste[1][i] = TEX; }
					if(((last == TEX) && (next == TEX)) && (length < 8)) { liste[1][i] = TEX; }
				}
			}
		}
	}
	regroupe(indexliste);
	/* 520 */
	for(i = 0; i < *(indexliste); i++) {
		this = liste[1][i];
		length = liste[0][i];
		if(i != 0) { last = liste[1][i - 1]; } else { last = FALSE; }
		if(i != *(indexliste) - 1) { next = liste[1][i + 1]; } else { next = FALSE; }
		
		if((this == TEX) && (i > 0)) { /* not the first */
			if(i == *(indexliste) - 1) { /* the last one */
				if((last == BYT) && (length == 1)) { liste[1][i] = BYT; }
			} else { /* not the last one */
				if(((last == BYT) && (next == BYT)) && (length < 5)) { liste[1][i] = BYT; }
				if((((last == BYT) && (next != BYT)) || ((last != BYT) && (next == BYT))) && (length < 3)) { liste[1][i] = BYT; }
			}
		}
	}
	/* 540 */
	regroupe(indexliste);
}

/* 547 */
void textprocess(int *chainemc, int *mclength, char chaine[], int start, int length, int block, FILE *file_pointer)
{
	int j, indexlistet, curtable, listet[2][5000], chainet[5000], wnet, mode;
	char codeascii;
	
	codeascii = 0;
	wnet = 0;
	
	if(file_pointer == 0) { mode = DIRECTMODE; } else { mode = FILEMODE; }
	
	for(j = 0; j < 1000; j++) {
		listet[0][j] = 0;
	}
	/* listet will contain the table numbers and the value of each characters */
	for(indexlistet = 0; indexlistet < length; indexlistet++) {
		if(mode == FILEMODE) {
			fseek(file_pointer, (start + indexlistet), SEEK_SET);
			codeascii = getc(file_pointer);
		} else {
			codeascii = chaine[start + indexlistet];
		}
		switch(codeascii) {
			case '\t': listet[0][indexlistet] = 12; listet[1][indexlistet] = 12; break;
			case '\n': listet[0][indexlistet] = 8; listet[1][indexlistet] = 15; break;
			case 13: listet[0][indexlistet] = 12; listet[1][indexlistet] = 11; break;
			default: listet[0][indexlistet] = asciix[codeascii - 32];
			listet[1][indexlistet] = asciiy[codeascii - 32]; break;
		}
	}

	/* 570 */
	curtable = 1; /* default table */
	for(j = 0; j < length; j++) {
		if(listet[0][j] & curtable) { /* The character is in the current table */
			chainet[wnet] = listet[1][j];
			wnet++;
		} else { /* Obliged to change table */
			int flag = FALSE; /* True if we change table for only one character */
			if (j == (length - 1)) {
				flag = TRUE;
			} else {
				if(!(listet[0][j] & listet[0][j + 1])) { flag = TRUE; }
			}
						
			if (flag) { /* we change only one character - look for temporary switch */
				if((listet[0][j] & 1) && (curtable == 2)) { /* T_UPP */
					chainet[wnet] = 27;
					chainet[wnet + 1] = listet[1][j];
					wnet += 2;
				}
				if(listet[0][j] & 8) { /* T_PUN */
					chainet[wnet] = 29;
					chainet[wnet + 1] = listet[1][j];
					wnet += 2;
				}
				if(!(((listet[0][j] & 1) && (curtable == 2)) || (listet[0][j] & 8))) {
					/* No temporary switch available */
					flag = FALSE;
				}
			}
						
			/* 599 */
			if (!(flag)) {
				int newtable;
							
				if(j == (length - 1)) {
					newtable = listet[0][j];
				} else {
					if(!(listet[0][j] & listet[0][j])) {
						newtable = listet[0][j];
					} else {
						newtable = listet[0][j] & listet[0][j + 1];
					}
				}
							
				/* Maintain the first if several tables are possible */
				switch (newtable) {
					case 3:
					case 5:
					case 7:
					case 9:
					case 11:
					case 13:
					case 15:
						newtable = 1; break;
					case 6:
					case 10:
					case 14:
						newtable = 2; break;
					case 12:
						newtable = 4; break;
				}
							
				/* 619 - select the switch */
				switch (curtable) {
					case 1: 
						switch (newtable) {
							case 2: chainet[wnet] = 27; wnet++; break;
							case 4: chainet[wnet] = 28; wnet++; break;
							case 8: chainet[wnet] = 28; wnet++; chainet[wnet] = 25; wnet++;  break;
						} break;
					case 2: 
						switch (newtable) {
							case 1: chainet[wnet] = 28; wnet++; chainet[wnet] = 28; wnet++;  break;
							case 4: chainet[wnet] = 28; wnet++;  break;
							case 8: chainet[wnet] = 28; wnet++; chainet[wnet] = 25; wnet++;  break;
						} break;
					case 4:
						switch (newtable) {
							case 1: chainet[wnet] = 28; wnet++;  break;
							case 2: chainet[wnet] = 27; wnet++;  break;
							case 8: chainet[wnet] = 25; wnet++;  break;
						} break;
					case 8:
						switch (newtable) {
							case 1: chainet[wnet] = 29; wnet++;  break;
							case 2: chainet[wnet] = 29; wnet++; chainet[wnet] = 27; wnet++;  break;
							case 4: chainet[wnet] = 29; wnet++; chainet[wnet] = 28; wnet++;  break;
						} break;
				}
				curtable = newtable;
				/* 659 - at last we add the character */
				chainet[wnet] = listet[1][j];
				wnet++;
			}
		}
	}
	
	/* 663 */
	if ((wnet % 2) > 0) {
		chainet[wnet] = 29;
		wnet++;
	}

	/* Now translate the string chainet into codewords */
	if (block > 0) {
		chainemc[*(mclength)] = 900;
		*(mclength) = *(mclength) + 1;
	}
	
	for(j = 0; j < wnet; j+= 2) {
		int cw_number;
		
		cw_number = (30 * chainet[j]) + chainet[j + 1];
		chainemc[*(mclength)] = cw_number;
		*(mclength) = *(mclength) + 1;
		
	}
}

/* 671 */
void byteprocess(int *chainemc, int *mclength, char chaine[], int start, int length, int block, FILE *file_pointer)
{
	int j, k, loop, longueur, mode;
	double multiple, total;
	
	if(file_pointer == 0) { mode = DIRECTMODE; } else { mode = FILEMODE; }
	
	if(length == 1) {
		chainemc[*(mclength)] = 913;
		if (mode == FILEMODE) {
			fseek(file_pointer, start, SEEK_SET);
			chainemc[*(mclength) + 1] = getc(file_pointer);
		} else {
			chainemc[*(mclength) + 1] = chaine[start];
		}
		*(mclength) = *(mclength) + 2;
	} else {
		/* select the switch for multiple of 6 bytes */
		if (length % 6 == 0) {
			chainemc[*(mclength)] = 924;
			*(mclength) = *(mclength) + 1;
		} else {
			chainemc[*(mclength)] = 901;
			*(mclength) = *(mclength) + 1;
		}
		
		j = 0;
		while(j < length) {
			longueur = length - j;
			if (longueur >= 6) { /* Take groups of 6 */
				
				int cw[5];
				
				longueur = 6;
				total = 0.0;
				for(k = 0; k < longueur; k++) {
					multiple = 1.0;
					
					for(loop = 0; loop < (longueur - k - 1); loop++) {
						multiple *= 256;
					}
					if(mode == FILEMODE) {
						fseek(file_pointer, (start + j + k), SEEK_SET);
						total += getc(file_pointer) * multiple;
					} else {
						total += chaine[start + j + k] * multiple;
					}
				}
				
				/* 693 */
				/* gcc handles this nicely without resorting to
				carrying out the calculation step by step */
				for(loop = 0; loop < 5; loop++) {
					double fraction, big_int;
					
					fraction = total / 900;
					big_int = 1000000000.0;
					do {
						while(fraction > big_int) {
							fraction -= big_int;
						}
						big_int /= 10;
					} while(big_int > 1.0);

					cw[loop] = fraction * 900;
					total = (total / 900) - fraction;
				}
				
				for(loop = 4; loop >= 0; loop--) {
					chainemc[*(mclength)] = cw[loop];
					*(mclength) = *(mclength) + 1;
				}

			} else {
				/* If there remains a group of less than 6 bytes */
				for(k = 0; k < longueur; k++) {
					if(mode == FILEMODE) {
						fseek(file_pointer, (start + j + k), SEEK_SET);
						chainemc[*(mclength)] += getc(file_pointer);
					} else {
						chainemc[*(mclength)] = chaine[start + j + k];
					}
					*(mclength) = *(mclength) + 1;
				}
			}
			j += longueur;
		}
	}
}

/* 712 */
void numbprocess(int *chainemc, int *mclength, char chaine[], int start, int length, int block, FILE *file_pointer)
{
	int j, loop, longueur, dummy[100], dumlength, diviseur, nombre, mode;
	char chainemod[50], chainemult[100], temp;
	
	if(file_pointer == 0) { mode = DIRECTMODE; } else { mode = FILEMODE; }
	
	strcpy(chainemod, "");
	for(loop = 0; loop <= 50; loop++) {
		dummy[loop] = 0;
	}
	dumlength = 0;
	
	chainemc[*(mclength)] = 902;
	*(mclength) = *(mclength) + 1;

	j = 0;
	while(j < length) {
		strcpy(chainemod, "");
		longueur = length - j;
		if(longueur > 44) { longueur = 44; }
		concat(chainemod, "1");
		for(loop = 1; loop <= longueur; loop++) {
			if(mode == FILEMODE) {
				fseek(file_pointer, start + loop + j - 1, SEEK_SET);
				chainemod[loop] = getc(file_pointer);
			} else {
				chainemod[loop] = chaine[start + loop + j - 1];
			}
		}
		chainemod[longueur + 1] = '\0';
		do {
			diviseur = 900;
			
			/* 877 - gosub Modulo */
			strcpy(chainemult, "");
			nombre = 0;
			while(strlen(chainemod) != 0) {
				nombre *= 10;
				nombre += ctoi(chainemod[0]);
				for(loop = 0; loop < strlen(chainemod); loop++) {
					chainemod[loop] = chainemod[loop + 1];
				}
				if (nombre < diviseur) {
					if (strlen(chainemult) != 0) { concat(chainemult, "0"); }
				} else {
					temp = (nombre / diviseur) + '0';
					chainemult[strlen(chainemult) + 1] = '\0';
					chainemult[strlen(chainemult)] = temp;
				}
				nombre = nombre % diviseur;
			}
			diviseur = nombre;
			/* return to 723 */
			
			for(loop = dumlength; loop > 0; loop--) {
				dummy[loop] = dummy[loop - 1];
			}
			dummy[0] = diviseur;
			dumlength++;
			strcpy(chainemod, chainemult);
		} while(strlen(chainemult) != 0);
		for(loop = 0; loop < dumlength; loop++) {
			chainemc[*(mclength)] = dummy[loop];
			*(mclength) = *(mclength) + 1;
		}
		j += longueur;
	}
}

/* 366 */
void pdf417(char chaine[], int *su, int *nbcol, int *codeerr, char inputfile[], struct symbol_struct *symbol, int symboltype, int out_type)
{
	int i, k, j, indexchaine, indexliste, mode, longueur, loop, mccorrection[520], offset;
	int total, chainemc[2700], mclength, c1, c2, c3, dummy[35], inputmode;
	char inbuffer, codebarre[100], pattern[580];
	FILE *file_pointer;
	
	file_pointer = 0;
	*(codeerr) = 0;
	
	/* 456 */
	if(!(strcmp(chaine, ""))) {
		inputmode = FILEMODE;
		if(inputfile[0] != '\0') {
			*(codeerr) = 1;
			return;
		}
	} else {
		inputmode = DIRECTMODE;
	}
	

	indexliste = 0;
	indexchaine = 0;
	
	if(inputmode == FILEMODE) {
		file_pointer = fopen(inputfile, "r");
		if(file_pointer == 0) {
			*(codeerr) = 1;
			return;
		}
		inbuffer = getc(file_pointer);
		mode = quelmode(inbuffer);
	} else {
		mode = quelmode(chaine[indexchaine]);
	}
	
	for(i = 0; i < 1000; i++) {
		liste[0][i] = 0;
	}
	
	if(inputmode == FILEMODE) {
		do {
			liste[1][indexliste] = mode;
			while ((liste[1][indexliste] == mode) && (!feof(file_pointer))) {
				liste[0][indexliste]++;
				indexchaine++;
				inbuffer = getc(file_pointer);
				mode = quelmode(inbuffer);
			}
			indexliste++;
		} while (!feof(file_pointer));
	} else {
		/* 463 */
		do {
			liste[1][indexliste] = mode;
			while ((liste[1][indexliste] == mode) && (indexchaine < strlen(chaine))) {
				liste[0][indexliste]++;
				indexchaine++;
				mode = quelmode(chaine[indexchaine]);
			}
			indexliste++;
		} while (indexchaine < strlen(chaine));
	}
	
	if(inputmode == FILEMODE) {
		/* reset file_pointer to the beginning of the file */
		fseek(file_pointer, 0, SEEK_SET);
	}
	
	/* 474 */
	pdfsmooth(&indexliste);
	
	/* 541 - now compress the data */
	indexchaine = 0;
	mclength = 0;
	for(i = 0; i < indexliste; i++) {
		switch(liste[1][i]) {
			case TEX: /* 547 - text mode */
				textprocess(chainemc, &mclength, chaine, indexchaine, liste[0][i], i, file_pointer);
				break;
			case BYT: /* 670 - octet stream mode */
				byteprocess(chainemc, &mclength, chaine, indexchaine, liste[0][i], i, file_pointer);
				break;
			case NUM: /* 712 - numeric mode */
				numbprocess(chainemc, &mclength, chaine, indexchaine, liste[0][i], i, file_pointer);
				break;
		}
	}

	if(inputmode == FILEMODE) {
		fclose(file_pointer);
	}

	/* 752 - Now take care of the number of CWs per row */
	if (*(su) < 0) {
		/* note that security level 8 is never used automatically */
		*(su) = 7;
		if(mclength <= 1280) { *(su) = 6; }
		if(mclength <= 640) { *(su) = 5; }
		if(mclength <= 320) { *(su) = 4; }
		if(mclength <= 160) { *(su) = 3; }
		if(mclength <= 40) { *(su) = 2; }
	}
	k = 1;
	for(loop = 1; loop <= (*(su) + 1); loop++)
	{
		k *= 2;
	}
	printf("PDF417 adding %d check codewords (PDF correction level %d)\n", k, *(su));
	longueur = mclength;
	if(*(nbcol) > 30) { *(nbcol) = 30; }
	if(*(nbcol) < 1) {
		/* This is a much more simple formula to Grand Zebu's - 
		   it does not try to make the symbol square */
		*(nbcol) = 0.5 + sqrt((longueur + k) / 3);
	}
	if(((longueur + k) / *(nbcol)) > 90) {
		/* stop the symbol from becoming too high */
		*(nbcol) = *(nbcol) + 1;
	}

	/* Reduce the correction level if there isn't room */
	/* while((longueur + k > PDF_MAX) && (*(su) > 0)) {
		*(su) = *(su) - 1;
		for(loop = 0; loop <= (*(su) + 1); loop++)
		{
			k *= 2;
		}
	} */
	/* this bit of the code would allow Zint to happily encode 2698 code words with
	only 2 check digits, so I have abandoned it! - Zint now insists on a proportional
	amount of check data unless overruled by the user */
	
	if(longueur + k > PDF_MAX) {
		*(codeerr) = 2;
		return;
	}
	/* 781 - Padding calculation */
	longueur = mclength + 1 + k;
	i = 0;
	if ((longueur / *(nbcol)) < 3) {
		i = (*(nbcol) * 3) - longueur; /* A bar code must have at least three rows */
	} else {
		if((longueur % *(nbcol)) > 0) { i = *(nbcol) - (longueur % *(nbcol)); }
	}
	/* We add the padding */
	while (i > 0) {
		chainemc[mclength] = 900;
		mclength++;
		i--;
	}
	/* we add the length descriptor */
	for(i = mclength; i > 0; i--) {
		chainemc[i] = chainemc[i - 1];
	}
	chainemc[0] = mclength + 1;
	mclength++;

	/* 796 - we now take care of the Reed Solomon codes */
	switch(*(su)) {
		case 1: offset = 2; break;
		case 2: offset = 6; break;
		case 3: offset = 14; break;
		case 4: offset = 30; break;
		case 5: offset = 62; break;
		case 6: offset = 126; break;
		case 7: offset = 254; break;
		case 8: offset = 510; break;
		default: offset = 0; break;
	}

	longueur = mclength;
	for(loop = 0; loop < 520; loop++) {
		mccorrection[loop] = 0;
	}
	total = 0;
	for(i = 0; i < longueur; i++) {
		total = (chainemc[i] + mccorrection[k - 1]) % 929;
		for(j = k - 1; j >= 0; j--) {
			if(j == 0) {
				mccorrection[j] = (929 - (total * coefrs[offset + j]) % 929) % 929;
			} else {
				mccorrection[j] = (mccorrection[j - 1] + 929 - (total * coefrs[offset + j]) % 929) % 929;
			}
		}
	}
	
	for(j = 0; j < k; j++) {
		if(mccorrection[j] != 0) { mccorrection[j] = 929 - mccorrection[j]; }
	}
	/* we add these codes to the string */
	for(i = k - 1; i >= 0; i--) {
		chainemc[mclength] = mccorrection[i];
		mclength++;
	}
	
	/* 818 - The CW string is finished */
	c1 = (mclength / *(nbcol) - 1) / 3;
	c2 = *(su) * 3 + (mclength / *(nbcol) - 1) % 3;
	c3 = *(nbcol) - 1;
	
	if(symboltype == PDF417) {
		printf("PDF417 symbol size: %dx%d codewords\n", *(nbcol) + 2, (mclength / *(nbcol)));
	} else {
		printf("PDF417 symbol size: %dx%d codewords\n", *(nbcol) + 1, (mclength / *(nbcol)));
	}
	/* we now encode each row */
	for(i = 0; i <= (mclength / *(nbcol)) - 1; i++) {
		for(j = 0; j < *(nbcol) ; j++) {
			dummy[j + 1] = chainemc[i * *(nbcol) + j];
		}
		k = (i / 3) * 30;
		switch(i % 3) {
			case 0:
				dummy[0] = k + c1;
				dummy[*(nbcol) + 1] = k + c3;
				break;
			case 1:
				dummy[0] = k + c2;
				dummy[*(nbcol) + 1] = k + c1;
				break;
			case 2:
				dummy[0] = k + c3;
				dummy[*(nbcol) + 1] = k + c2;
				break;
		}
		strcpy(codebarre, "+*"); /* Start with a start char and a separator */
		if(symboltype == PDF417) {
			for(j = 0; j <= *(nbcol) + 1;  j++) {
				switch(i % 3) {
					case 1: offset = 929; break;
					case 2: offset = 1858; break;
					default: offset = 0; break;
				}
				concat(codebarre, codagemc[offset + dummy[j]]);
				concat(codebarre, "*");
			}
			concat(codebarre, "-");
		} else {
			/* truncated - so same as before except knock off the last 5 chars */
			for(j = 0; j <= *(nbcol);  j++) {
				switch(i % 3) {
					case 1: offset = 929; break;
					case 2: offset = 1858; break;
					default: offset = 0; break;
				}
				concat(codebarre, codagemc[offset + dummy[j]]);
				concat(codebarre, "*");
			}
		}
		
		if(out_type == FONT) {
			printf("%s\n", codebarre);
		}
		
		strcpy(pattern, "");
		for(loop = 0; loop < strlen(codebarre); loop++) {
			lookup(BRSET, PDFttf, codebarre[loop], pattern);
		}
		for(loop = 0; loop < strlen(pattern); loop++) {
			symbol->encoded_data[i][loop] = pattern[loop];
		}
	}
	symbol->no_of_rows = (mclength / *(nbcol));
	symbol->max_width = strlen(pattern);
	
	/* 843 */
	return;
}

/* 345 */
void pdf417enc(int su, int nbcol, struct symbol_struct *symbol, char text1[], unsigned char inputfile[], int symboltype, int out_type)
{
	int codeerr;

	if((su < -1)||(su > 8)) { su = -1; printf("warning: security value out of range\n"); }
	if((nbcol < 0)||(nbcol > 30)) { nbcol = 0; printf("warning: number of columns out of range\n"); }
	
	if(strlen(text1) != 0) {
		prescan(text1);
	}
	symbol->symbology_type = PDF;
	
	/* 349 */
	pdf417(text1, &su, &nbcol, &codeerr, inputfile, symbol, symboltype, out_type);
	
	/* 352 */
	if(codeerr != 0) {
		switch(codeerr) {
			case 1:
				fprintf(stderr, "error: no such file or file unreadable (PDF error 1)\n");
				break;
			case 2:
				fprintf(stderr, "error: input file or string too long (PDF error 2)\n");
				break;
			case 3:
				fprintf(stderr, "error: number of codewords per row too small (PDF error 3)\n");
				break;
			default:
				/* should never get here */
				fprintf(stderr, "error: something strange happened (PDF error %d)\n,", codeerr);
				break;
		}
		exit(TRUE);
	}
	
	/* 364 */
	return;
}
