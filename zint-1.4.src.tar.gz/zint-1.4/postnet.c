/* postnet.c - Handles PostNet, PLANET and FIM */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include "common.h"

#define BESET	"ABCD"

/* PostNet number encoding table - In this table L is long as S is short */
static char *PNTable[10] = {"LLSSS", "SSSLL", "SSLSL", "SSLLS", "SLSSL", "SLSLS", "SLLSS", "LSSSL",
	"LSSLS", "LSLSS"};
static char *PLTable[10] = {"SSLLL", "LLLSS", "LLSLS", "LLSSL", "LSLLS", "LSLSL", "LSSLL", "SLLLS",
	"SLLSL", "SLSLL"};
	
static char *FIMTable[4] = {"22122", "1121211", "2111112", "31113"};
	
void postnet(char source[], char dest[])
{
	/* Handles the PostNet system used for Zip codes in the US */
	unsigned int i, sum, check_digit;

	if(strlen(source) > 90) {
		fprintf(stderr, "Postnet input too long\n");
		exit(TRUE);
	}
	is_sane(NESET, source);
	sum = 0;

	/* start character */
	concat (dest, "L");

	for (i=0; i < strlen(source); i++)
	{
		lookup(NESET, PNTable, source[i], dest);
		sum += ctoi(source[i]);
	}

	check_digit = 10 - (sum%10);
	printf("POSTNET check digit '%d'\n", check_digit);
	concat(dest, PNTable[check_digit]);

	/* stop character */
	concat (dest, "L");
}

void post_plot(int *stack_row, struct symbol_struct *symbol, char argument[])
{
	/* Puts PostNet barcodes into the pattern matrix */
	char height_pattern[200];
	unsigned int loopey;
	int writer;
	strcpy(height_pattern, "");

	postnet(argument, height_pattern);

	writer = 0;
	for(loopey = 0; loopey < strlen(height_pattern); loopey++)
	{
		if(height_pattern[loopey] == 'L')
		{
			symbol->encoded_data[0][writer] = '1';
		}
		symbol->encoded_data[1][writer] = '1';
		writer += 2;
	}
	(*stack_row) = 2;
	symbol->no_of_rows = 2;
	symbol->max_width = writer - 1;
}

void planet(char source[], char dest[])
{
	/* Handles the PLANET  system used for item tracking in the US */
	unsigned int i, sum, check_digit;
	
	if(strlen(source) > 90) {
		fprintf(stderr, "Planet input too long\n");
		exit(TRUE);
	}
	is_sane(NESET, source);
	sum = 0;

	/* start character */
	concat (dest, "L");

	for (i=0; i < strlen(source); i++)
	{
		lookup(NESET, PLTable, source[i], dest);
		sum += ctoi(source[i]);
	}

	check_digit = 10 - (sum%10);
	printf("PLANET check digit '%d'\n", check_digit);
	concat(dest, PLTable[check_digit]);

	/* stop character */
	concat (dest, "L");
}

void planet_plot(int *stack_row, struct symbol_struct *symbol, char argument[])
{
	/* Puts PLANET barcodes into the pattern matrix */
	char height_pattern[200];
	unsigned int loopey;
	int writer;
	strcpy(height_pattern, "");

	planet(argument, height_pattern);

	writer = 0;
	for(loopey = 0; loopey < strlen(height_pattern); loopey++)
	{
		if(height_pattern[loopey] == 'L')
		{
			symbol->encoded_data[0][writer] = '1';
		}
		symbol->encoded_data[1][writer] = '1';
		writer += 2;
	}
	(*stack_row) = 2;
	symbol->no_of_rows = 2;
	symbol->max_width = writer - 1;
}

void fim(char source[], char dest[])
{
	/* The simplest barcode symbology ever! Supported by MS Word, so here it is! */
	/* glyphs from http://en.wikipedia.org/wiki/Facing_Identification_Mark */
	to_upper(source);
	if(strlen(source) > 1) {
		fprintf(stderr, "FIM input too long\n");
		exit(TRUE);
	}
	is_sane(BESET, source);
	lookup(BESET, FIMTable, source[0], dest);
}
