/* zint.c - Command line handling routines for Zint */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include "common.h"
#include "zint.h"

void usage(void)
{
	fprintf(stderr,
		"Zint version 1.3.1\n"
		"Encode input data in a barcode and save as a PNG image.\n\n"
		"  -h, --help            Display this message.\n"
		"  -o, --output=FILE     Write PNG image to FILE. (default is out.png)\n"
		"  -i, --input=FILE      Read data from FILE (PDF417 and Data Matrix only)\n"
		"  -d, --data=DATA       Barcode content.\n"
		"  -b, --barcode=NUMBER  Number of barcode type (default is 20 (=Code128)).\n"
		"  -h, --height=HEIGHT   Height of symbol in pixels.\n"
		"  -w, --whitesp=NUMBER  Width of whitespace in pixels.\n"
		"  --border=NUMBER       Width of border in pixels.\n"
		"  --box                 Add a box.\n"
		"  --bind                Add boundary bars.\n"
		"  -r, --reverse         Reverse colours (white on black).\n"
		"  --fg=COLOUR           Specify a foreground colour.\n"
		"  --bg=COLOUR           Specify a background colour.\n"
		"  --cols=NUMBER         (PDF417) Number of columns.\n"
		"  --secure=NUMBER       (PDF417) Error correction level.\n"
	);
}

void add_to_stack(int mode, int *stack_row, struct symbol_struct *symbol, char argument[])
{
	char width_pattern[500];
	unsigned int reader, current_width, writer;
	int looper, flip_flop;

	strcpy(width_pattern, "");

	if((*stack_row) == 0) { symbol->symbology_type = ONEDIM; }
	if((*stack_row) > 0) { symbol->symbology_type = STACKED; }

	switch(mode)
	{
		case C25MATRIX: matrix_two_of_five(argument, width_pattern); break;
		case C25IND: industrial_two_of_five(argument, width_pattern); break;
		case C25INTER: interleaved_two_of_five(argument, width_pattern); break;
		case C25IATA: iata_two_of_five(argument, width_pattern); break;
		case C25LOGIC: logic_two_of_five(argument, width_pattern); break;
		case DPLEIT: dpleit(argument, width_pattern); break;
		case DPIDENT: dpident(argument, width_pattern); break;
		case UPCA: eanx(mode, argument, width_pattern); break;
		case UPCE: eanx(mode, argument, width_pattern); break;
		case EAN: eanx(mode, argument, width_pattern); break;
		case EAN128: code_128(argument, width_pattern, mode); break;
		case CODE39: c39(argument, width_pattern); break;
		case PZN: pharmazentral(argument, width_pattern); break;
		case EXCODE39: ec39(argument, width_pattern); break;
		case CODABAR: codabar(argument, width_pattern); break;
		case CODE93: c93(argument, width_pattern); break;
		case CODE13: code_13(argument, width_pattern); break;
		case LOGMARS: logmars(argument, width_pattern); break;
		case ISBN: eanx(mode, argument, width_pattern); break;
		case CODE128: code_128(argument, width_pattern, mode); break;
		case CODE128B: code_128(argument, width_pattern, mode); break;
		case NVE18: code_128(argument, width_pattern, mode); break;
		case CODE11: code_11(argument, width_pattern); break;
		case MSI: msi_plessey(argument, width_pattern); break;
		case MSI10: msi_plessey_mod10(argument, width_pattern); break;
		case MSI1010: msi_plessey_mod1010(argument, width_pattern); break;
		case MSI11: msi_plessey_mod11(argument, width_pattern); break;
		case MSI1110: msi_plessey_mod1110(argument, width_pattern); break;
		case TELEPEN: telepen(argument, width_pattern); break;
		case TELENUM: telepen_num(argument, width_pattern); break;
		case PHARMA: pharma_one(argument, width_pattern); break;
		case PLESSEY: plessey(argument, width_pattern); break;
		case ITF14: itf14(argument, width_pattern); break;
		case KOREAPOST: korea(argument, width_pattern); break;
		case FLAT: flattermarken(argument, width_pattern); break;
		case FIM: fim(argument, width_pattern); break;
	}

	writer = 0;
	flip_flop = 1;
	for (reader = 0; reader < strlen(width_pattern); reader++) {
		for(looper = 0; looper < ctoi(width_pattern[reader]); looper++) {
			if(flip_flop == 1) {
				symbol->encoded_data[(*stack_row)][writer] = '1';
				writer++; }
			else {
				symbol->encoded_data[(*stack_row)][writer] = '0';
				writer++; }
		}
		if(flip_flop == 0) { flip_flop = 1; } else { flip_flop = 0; }
	}

	current_width = writer;
	if(current_width > symbol->max_width) { symbol->max_width = current_width; }
}

void plot_2d(int mode, int *stack_row, struct symbol_struct *symbol, char argument[], int out_type)
{
	switch(mode)
	{
		case POSTNET: post_plot(stack_row, symbol, argument);
			symbol->symbology_type = TWOTRACK; break;
		case PLANET: planet_plot(stack_row, symbol, argument);
			symbol->symbology_type = TWOTRACK; break;
		case RM4SCC: royal_plot(stack_row, symbol, argument, out_type);
			symbol->symbology_type = FOURSTATE; break;
		case AUSPOST: australia_post(stack_row, symbol, argument, out_type);
			symbol->symbology_type = FOURSTATE; break;
		case AUSREPLY: australia_reply_paid(stack_row, symbol, argument, out_type);
			symbol->symbology_type = FOURSTATE; break;
		case AUSROUTE: australia_routing(stack_row, symbol, argument, out_type);
			symbol->symbology_type = FOURSTATE; break;
		case AUSREDIRECT: australia_redirection(stack_row, symbol, argument, out_type);
			symbol->symbology_type = FOURSTATE; break;
		case CODE16K: code16k(stack_row, symbol, argument);
			symbol->symbology_type = SIXTEEN; break;
		case PHARMA2: pharma_two(stack_row, symbol, argument);
			symbol->symbology_type = TWOTRACK; break;
		case ONECODE: imail(stack_row, symbol, argument, out_type);
			symbol->symbology_type = FOURSTATE; break;
	}
}

void encode(int mode, int *stack_row, struct symbol_struct *symbol, char argument[], int out_type)
{
	switch(mode)
	{
		case UPCA:
		case EAN:
		case EAN128:
		case UPCE:
		case CODE39:
		case EXCODE39:
		case CODABAR:
		case CODE93:
		case CODE13:
		case LOGMARS:
		case ISBN:
		case CODE128:
		case CODE128B:
		case NVE18:
		case C25MATRIX:
		case C25IND:
		case C25INTER:
		case C25IATA:
		case C25LOGIC:
		case DPLEIT:
		case DPIDENT:
		case PZN:
		case CODE11:
		case MSI:
		case MSI10:
		case MSI1010:
		case MSI11:
		case MSI1110:
		case TELEPEN:
		case TELENUM:
		case PLESSEY:
		case PHARMA:
		case ITF14:
		case KOREAPOST:
		case FLAT:
		case FIM:
			if((*stack_row) <= 16) {
				add_to_stack(mode, stack_row, symbol, argument);
				(*stack_row)++;
				symbol->no_of_rows++;
			}
			break;
		default:
			if((*stack_row) == 0) {
				plot_2d(mode, stack_row, symbol, argument, out_type);
			}
			break;
	}
}

int main(int argc, char **argv)
{
	struct symbol_struct symbol;
	int i, mode, stack_row, colnum, seclevel, lock, out_type;
	unsigned int l, done;
	char infront[8];
	char inback[8];
	char *inputfile;
	char matrix_ecc[5], matrix_size[8];
	int c;
	
	out_type = 2;
	done = FALSE;
	stack_row = 0;
	symbol.no_of_rows = 0;
	symbol.max_width = 0;
	for(i = 0; i < 16; i++) { for(l = 0; l <= 1000; l++) { symbol.encoded_data[i][l] = '0'; } }

	/* Set the defaults - these values overwritten if specified by user */
	symbol.bind = FALSE;
	symbol.box = FALSE;
	symbol.border_width = 12;
	symbol.whitespace_width = 30;
	strcpy(symbol.outfile, "out.png");
	strcpy(infront, "000000");
	strcpy(inback, "ffffff");
	strcpy(matrix_ecc, "200");
	strcpy(matrix_size, "");
	symbol.user_height = 0; /* Note: this does not mean a height of 0 pixels but that the
				   height has not been specified by the user (default is 200px) */
	mode = CODE128; 
	seclevel = -1;
	colnum = 0;
	lock = FALSE; /* This locks out the computation of additional barcode sequences if
			 the barcode type selected is one which cannot be stacked and if the
			 encoding has already been completed */
	

	if(argc == 1) {
		usage();
		return 0;
	}

	while(1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"help", 0, 0, 'h'},
			{"font", 0, 0, 0},
			{"bind", 0, 0, 0},
			{"box", 0, 0, 0},
			{"barcode=", 1, 0, 'b'},
			{"height=", 1, 0, 0},
			{"whitesp=", 1, 0, 'w'},
			{"boder=", 0, 0, 0},
			{"data=", 1, 0, 'd'},
			{"output=", 1, 0, 'o'},
			{"input=", 1, 0, 'i'},
			{"fg=", 1, 0, 0},
			{"bg=", 1, 0, 0},
			{"cols=", 1, 0, 0},
			{"secure=", 1, 0, 0},
			{"reverse", 1, 0, 'r'},
			{0, 0, 0, 0}
		};
		c = getopt_long(argc, argv, "hb:w:d:o:i:r", long_options, &option_index);
		if(c == -1) break;

		switch(c) {
			case 0:
				if(!strcmp(long_options[option_index].name, "font")) {
					out_type = FONT;
				}
				if(!strcmp(long_options[option_index].name, "bind")) {
					symbol.bind = TRUE;
				}
				if(!strcmp(long_options[option_index].name, "box")) {
					symbol.box = TRUE;
				}
				if(!strcmp(long_options[option_index].name, "fg=")) {
					strncpy(infront, optarg, 7);
				}
				if(!strcmp(long_options[option_index].name, "bg=")) {
					strncpy(inback, optarg, 7);
				}
				if(!strcmp(long_options[option_index].name, "border=")) {
					is_sane(NESET, optarg);
					if((atoi(optarg) >= 0) && (atoi(optarg) <= 1000)) {
						symbol.border_width = atoi(optarg);
					} else {
						fprintf(stderr, "error: border width out of range\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "cols=")) {
					is_sane(NESET, optarg);
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 30)) {
						colnum = atoi(optarg);
					} else {
						fprintf(stderr, "error: number of columns out of range\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "secure=")) {
					is_sane(NESET, optarg);
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 8)) {
						seclevel = atoi(optarg);
					} else {
						fprintf(stderr, "error: error correction level out of range\n");
					}
				}
				break;
				
			case 'h':
				usage();
				break;
				
			case 'b':
				is_sane(NESET, optarg);
				mode = atoi(optarg);
				if(mode < 1) { fprintf(stderr, "error: invalid barcode type\n"); mode = CODE128; }
				
				/* modes 1 to 86 are defined by tbarcode */
				if(mode == 5) { mode = C25MATRIX; }
				if((mode >= 10) && (mode <= 12)) { mode = EAN; }
				if((mode == 14) || (mode == 16)) { mode = EAN; }
				if(mode == 17) { mode = UPCA; }
				if(mode == 19) { fprintf(stderr, "Codabar 18 not currently supported\n"); mode = CODABAR; }
				if(mode == 24) { fprintf(stderr, "Code 49 not currently supported\n"); mode = CODE93; }
				if(mode == 26) { mode = UPCA; }
				if(mode == 27) { fprintf(stderr, "UPCD1 not currently supported\n"); mode = CODE128; }
				if((mode >= 29) && (mode <= 31)) { fprintf(stderr, "RSS not currently supported\n"); mode = CODE128; }
				if(mode == 33) { mode = EAN128; }
				if((mode == 35) || (mode == 36)) { mode = UPCA; }
				if((mode == 38) || (mode == 39)) { mode = UPCE; }
				if((mode >= 41) && (mode <= 45)) { mode = POSTNET; }
				if(mode == 46) { mode = PLESSEY; }
				if(mode == 48) { mode = NVE18; }
				if(mode == 54) { fprintf(stderr, "General Parcel not currently supported\n"); mode = CODE128; }
				if(mode == 57) { fprintf(stderr, "MaxiCode not currently supported\n"); mode = MATRIX; }
				if(mode == 58) { fprintf(stderr, "QR Code not currently supported\n"); mode = MATRIX; }
				if((mode == 59) || (mode == 61)) { mode = CODE128; }
				if(mode == 62) { mode = CODE93; }
				if((mode == 64) || (mode == 65)) { mode = AUSPOST; }
				if(mode == 73) { fprintf(stderr, "Codablock E not currently supported\n"); mode = CODE16K; }
				if(mode == 74) { fprintf(stderr, "Codablock F not currently supported\n"); mode = CODE16K; }
				if(mode == 76) { fprintf(stderr, "Japanese Postal Code not currently supported\n"); }
				if(mode == 77) { fprintf(stderr, "Korean Postal Code support not finished!\n"); }
				if((mode >= 78) && (mode <= 81)) { printf("RSS not currently supported\n"); mode = CODE128; }
				if(mode == 83) { mode = PLANET; }
				if(mode == 84) { fprintf(stderr, "MicroPDF417 not currently supported\n"); mode = PDF417; }
				/* leave a gap for future expansion of tbarcode */
				if((mode >= 87) && (mode <= 98)) { printf("invalid barcode type\n"); mode = CODE128; }
				if(mode >= 105) { fprintf(stderr, "invalid barcode type\n"); mode = CODE128; }
				break;
				
			case 'w':
				is_sane(NESET, optarg);
				if((atoi(optarg) >= 0) && (atoi(optarg) <= 1000)) {
					symbol.whitespace_width = atoi(optarg);
				} else {
					fprintf(stderr, "error: whitespace value out of range");
				}
				break;
				
			case 'd': /* we have some data! */
				if(lock == FALSE) {
					if((mode != PDF417) && (mode != PDF417TRUNC) && (mode != DATAMATRIX)) {
						/* these symbologies require input at the command prompt */
						encode(mode, &stack_row, &symbol, optarg, out_type);
						if(mode == CODE16K) { lock = TRUE; }
						if(mode == POSTNET) { lock = TRUE; }
						if(mode == PLANET) { lock = TRUE; }
						if(mode == RM4SCC) { lock = TRUE; }
						if(mode == AUSPOST) { lock = TRUE; }
						if(mode == AUSREPLY) { lock = TRUE; }
						if(mode == AUSREDIRECT) { lock = TRUE; }
						if(mode == AUSROUTE) { lock = TRUE; }
						if(mode == PHARMA2) { lock = TRUE; }
						if(mode == ONECODE) { lock = TRUE; }
					} else {
						/* these symbologies can input from a file */
						if((strlen(inputfile) == 0) && ((mode == PDF417) || (mode == PDF417TRUNC))) {
							pdf417enc(seclevel, colnum, &symbol, optarg, inputfile, mode, out_type);
							lock = TRUE;
						}
						if((strlen(inputfile) == 0) && (mode == DATAMATRIX)) {
							dmatrix(&symbol, optarg, matrix_ecc, inputfile, matrix_size);
							lock = TRUE;
						}
					}
				}
				break;
				
			case 'o':
				strncpy(symbol.outfile, optarg, 250);
				break;
				
			case 'i':
				strncpy(inputfile, optarg, 250);
				break;
				
			case 'r':
				strcpy(infront, "ffffff");
				strcpy(inback, "000000");
				break;
				
			case '?':
				break;
				
			default:
				printf("?? getopt error 0%o\n", c);
		}
	}
	
	if (optind < argc) {
		printf("Invalid option ");
		while (optind < argc)
			printf("%s", argv[optind++]);
		printf("\n");
	}
	
	if(((mode == PDF417) || (mode == PDF417TRUNC)) && (lock == FALSE)) {
		/* input from a file is required */
		pdf417enc(seclevel, colnum, &symbol, "", inputfile, mode, out_type);
	}
	if((mode == DATAMATRIX) && (lock == FALSE)) {
		/* Data Matrix input from file */
		dmatrix(&symbol, "", matrix_ecc, inputfile, matrix_size);
	}
	
	if(symbol.symbology_type == SIXTEEN) { symbol.bind = TRUE; }

	colourtag(infront, symbol.fgcolour); /* usually black */
	colourtag(inback, symbol.bgcolour); /* usually white */

	if((symbol.max_width != 0) && (out_type == PNG)) {
		/* some kind of encoding took place and there is data in the structure */
		png_plot(&symbol);
	}

	if((symbol.max_width != 0) && (out_type == FONT) && (!((symbol.symbology_type == FOURSTATE) || (symbol.symbology_type == PDF)))) {
		font_plot(&symbol);
	}
	
	return 0;
}
