/* codabar.c - Handles Codabar (AKA NW-7) */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "common.h"

#define CASET	"0123456789-$/:.+ABCD"
static char *CodaTable[20] = {"11111221", "11112211", "11121121", "22111111", "11211211", "21111211",
	"12111121", "12112111", "12211111", "21121111", "11122111", "11221111", "21111212", "21211121",
	"21212111", "11212121", "11221211", "12121121", "11121221", "11122211"};

int codabar(struct zint_symbol *symbol, char source[])
{ /* The Codabar system consisting of simple substitution */

	int i, errno;
	char dest[1000];
	
	errno = 0;
	strcpy(dest, "");

	if(strlen(source) > 60) { /* No stack smashing please */
		strcpy(symbol->errtxt, "error: input too long");
		return 6;
	}
	to_upper(source);
	errno = is_sane(CASET, source);
	if(errno == 7) {
		strcpy(symbol->errtxt, "error: invalid characters in data");
		return errno;
	}

	/* Codabar must begin and end with the characters A, B, C or D */
	if(((source[0] != 'A') && (source[0] != 'B')) &&
	((source[0] != 'C') && (source[0] != 'D')))
	{
		strcpy(symbol->errtxt, "error: invalid characters in data");
		return 6;
	}

	if(((source[strlen(source) - 1] != 'A') && (source[strlen(source) - 1] != 'B')) &&
	((source[strlen(source) - 1] != 'C') && (source[strlen(source) - 1] != 'D')))
	{
		strcpy(symbol->errtxt, "error: invalid characters in data");
		return 6;
	}

	for(i = 0; i <= strlen(source); i++)
	{
		lookup(CASET, CodaTable, source[i], dest);
	}
	
	concat(symbol->partial, "0");
	concat(symbol->partial, dest);
	expand(symbol, dest);
	strcpy(symbol->text, source);
	return errno;
}
