/* isbn.c - Handles SBN, ISBN and ISBN-13 validation */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "common.h"

void ean13(char source[], char dest[]);

char isbn13_check(char source[]) /* For ISBN(13) only */
{
	unsigned int i, weight, sum, check;

	sum = 0;
	weight = 1;

	for(i = 0; i < (strlen(source) - 1); i++)
	{
		sum += ctoi(source[i]) * weight;
		if(weight == 1) weight = 3; else weight = 1;
	}

	check = sum % 10;
	check = 10 - check;
	return itoc(check);
}

char isbn_check(char source[]) /* For ISBN(10) and SBN only */
{
	unsigned int i, weight, sum, check;

	sum = 0;
	weight = 1;
	for(i = 0; i < (strlen(source) - 1); i++)
	{
		sum += ctoi(source[i]) * weight;
		weight++;
	}

	check = sum % 11;
	return itoc(check);
}

void isbn(char source[], char dest[]) /* Make an EAN-13 barcode from an SBN or ISBN */
{
	int i;
	char check_digit;

	to_upper(source);
	is_sane("0123456789X", source);

	/* Input must be 9, 10 or 13 characters */
	if(((strlen(source) < 9) || (strlen(source) > 13)) || ((strlen(source) > 10) && (strlen(source) < 13)))
	{
		fprintf(stderr, "error: ISBN input '%s' wrong length\n", source);
		exit(TRUE);;
	}

	if(strlen(source) == 13) /* Using 13 character ISBN */
	{
		if(!(((source[0] == '9') && (source[1] == '7')) &&
		((source[2] == '8') || (source[2] == '9'))))
		{
			fprintf(stderr, "error: invalid ISBN '%s'\n", source);
			exit(TRUE);;
		}

		check_digit = isbn13_check(source);
		if (source[strlen(source) - 1] != check_digit)
		{
			fprintf(stderr, "error: invalid ISBN check digit '%s'\n", source);
			exit(TRUE);;
		}
		source[12] = '\0';

		ean13(source, dest);
	}

	if(strlen(source) == 10) /* Using 10 digit ISBN */
	{
		check_digit = isbn_check(source);
		if(check_digit != source[strlen(source) - 1])
		{
			fprintf(stderr, "error: invalid ISBN check digit '%s'\n", source);
			exit(TRUE);;
		}
		for(i = 13; i > 0; i--)
		{
			source[i] = source[i - 3];
		}
		source[0] = '9';
		source[1] = '7';
		source[2] = '8';
		source[12] = '\0';

		ean13(source, dest);
	}

	if(strlen(source) == 9) /* Using 9 digit SBN */
	{
		/* Add leading zero */
		for(i = 10; i > 0; i--)
		{
			source[i] = source[i - 1];
		}
		source[0] = '0';

		/* Verify check digit */
		check_digit = isbn_check(source);
		if(check_digit != source[strlen(source) - 1])
		{
			fprintf(stderr, "error: invalid SBN check digit '%s'\n", source);
			exit(TRUE);;
		}

		/* Convert to EAN-13 number */
		for(i = 13; i > 0; i--)
		{
			source[i] = source[i - 3];
		}
		source[0] = '9';
		source[1] = '7';
		source[2] = '8';
		source[12] = '\0';

		ean13(source, dest);
	}

}
