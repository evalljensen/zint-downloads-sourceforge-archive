/* plessey.c - Handles Plessey */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "common.h"


#define SSET	"0123456789ABCDEF"
static char *PlessTable[16] = {"13131313", "31131313", "13311313", "31311313", "13133113", "31133113",
	"13313113", "31313113", "13131331", "31131331", "13311331", "31311331", "13133131",
	"31133131", "13313131", "31313131"};

int plessey(struct zint_symbol *symbol, char source[])
{ /* Not MSI/Plessey but the older Plessey standard */

	unsigned int i, check;
	unsigned char *checkptr;
	static char grid[9] = {1,1,1,1,0,1,0,0,1};
	char dest[1000];
	int errno;
	
	errno = 0;
	strcpy(dest, "");
	
	if(strlen(source) > 65) {
		strcpy(symbol->errtxt, "error: input too long");
		return 6;
	}
	errno = is_sane(SSET, source);
	if(errno == 7) {
		strcpy(symbol->errtxt, "error: invalid characters in data");
		return errno;
	}
	checkptr = calloc (1, strlen(source) * 4 + 8);

	/* Start character */
	concat(dest, "31311331");

	/* Data area */
	for(i = 0; i <= strlen(source); i++)
	{
		check = posn(SSET, source[i]);
		lookup(SSET, PlessTable, source[i], dest);
		checkptr[4*i] = check & 1;
		checkptr[4*i+1] = (check >> 1) & 1;
		checkptr[4*i+2] = (check >> 2) & 1;
		checkptr[4*i+3] = (check >> 3) & 1;
	}

	/* CRC check digit code adapted from code by Leonid A. Broukhis
	   used in GNU Barcode */

	for (i=0; i < 4*strlen(source); i++) {
		int j;
		if (checkptr[i])
			for (j = 0; j < 9; j++)
				checkptr[i+j] ^= grid[j];
	}

	for (i = 0; i < 8; i++) {
		switch(checkptr[strlen(source) * 4 + i])
		{
			case 0: concat(dest, "13"); break;
			case 1: concat(dest, "31"); break;
		}
	}

	/* Stop character */
	concat(dest, "331311313");
	
	concat(symbol->partial, "0");
	concat(symbol->partial, dest);
	expand(symbol, dest);
	strcpy(symbol->text, source);
	return errno;
}
