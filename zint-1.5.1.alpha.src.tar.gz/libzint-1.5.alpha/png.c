/* png.c - Handles output to PNG file */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* Any resemblance to the code used by Greg Reolofs' wpng code examples is not
   coincidental. Rather odd use of mainprog_info in this file is due to gradual adaption
   from that code. Read his excellent book "PNG: The Definitive Guide" online at
   http://www.libpng.org/pub/png/book/ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "png.h"        /* libpng header; includes zlib.h and setjmp.h */
#include "common.h"

#define SSET	"0123456789ABCDEF"

struct mainprog_info_type {
    long width;
    long height;
    FILE *outfile;
    jmp_buf jmpbuf;
};

static void writepng_error_handler(png_structp png_ptr, png_const_charp msg)
{
    struct mainprog_info_type  *graphic;

    fprintf(stderr, "writepng libpng error: %s\n", msg);
    fflush(stderr);

    graphic = png_get_error_ptr(png_ptr);
    if (graphic == NULL) {         /* we are completely hosed now */
        fprintf(stderr,
          "writepng severe error:  jmpbuf not recoverable; terminating.\n");
        fflush(stderr);
        exit(99);
    }
    longjmp(graphic->jmpbuf, 1);
}

int png_plot(struct zint_symbol *symbol)
{
	struct mainprog_info_type wpng_info;
	struct mainprog_info_type *graphic;
	unsigned char outdata[6000];
	png_structp  png_ptr;
	png_infop  info_ptr;
	graphic = &wpng_info;
        long j;
        unsigned long rowbytes;
	unsigned char *image_data;
	int i, k, offset, row, row_binding, errno;
	int fgred, fggrn, fgblu, bgred, bggrn, bgblu;
	
	/* sort out colour options */
	to_upper(symbol->fgcolour);
	to_upper(symbol->bgcolour);
	
	if(strlen(symbol->fgcolour) != 6) {
		strcpy(symbol->errtxt, "error: malformed foreground colour target");
		return 10;
	}
	if(strlen(symbol->bgcolour) != 6) {
		strcpy(symbol->errtxt, "error: malformed background colour target");
		return 10;
	}
	errno = is_sane(SSET, symbol->fgcolour);
	if (errno == 7) {
		strcpy(symbol->errtxt, "error: malformed foreground colour target");
		return 10;
	}
	errno = is_sane(SSET, symbol->bgcolour);
	if (errno == 7) {
		strcpy(symbol->errtxt, "error: malformed background colour target");
		return 10;
	}
	
	fgred = (16 * ctoi(symbol->fgcolour[0])) + ctoi(symbol->fgcolour[1]);
	fggrn = (16 * ctoi(symbol->fgcolour[2])) + ctoi(symbol->fgcolour[3]);
	fgblu = (16 * ctoi(symbol->fgcolour[4])) + ctoi(symbol->fgcolour[5]);
	bgred = (16 * ctoi(symbol->bgcolour[0])) + ctoi(symbol->bgcolour[1]);
	bggrn = (16 * ctoi(symbol->bgcolour[2])) + ctoi(symbol->bgcolour[3]);
	bgblu = (16 * ctoi(symbol->bgcolour[4])) + ctoi(symbol->bgcolour[5]);
	
	/* calculate graphic width and height */
	graphic->width = (symbol->width * 2) + (symbol->border_width * 2) + (symbol->whitespace_width * 2);
	row_binding = 0;

	switch(symbol->symbology) {
		case BARCODE_AUSPOST:
		case BARCODE_AUSROUTE:
		case BARCODE_AUSREPLY:
		case BARCODE_AUSREDIRECT:
		case BARCODE_RM4SCC:
		case BARCODE_ONECODE:
			graphic->height = (4 * symbol->rows) + (2 * symbol->border_width);
			break;
		case BARCODE_PDF417:
		case BARCODE_PDF417TRUNC:
			graphic->height = (6 * symbol->rows) + (2 * symbol->border_width);
			break;
		case BARCODE_DATAMATRIX:
		case BARCODE_QRCODE:
			graphic->height = (2 * symbol->rows) + (2 * symbol->border_width);
			break;
		default: 
			if(symbol->height == 0) { graphic->height = 200; } else
			{ graphic->height = symbol->height + (symbol->border_width * 2); }
			if((symbol->rows > 1) && ((symbol->output_options == BARCODE_BIND) || (symbol->output_options == BARCODE_BOX))) {
				row_binding = 1;
			}
			break;
	}

	if(symbol->symbology == BARCODE_CODE16K) {
		row_binding = 1;
	}
	
	/* Open output file in binary mode */
	if (!(graphic->outfile = fopen(symbol->outfile, "wb"))) {
		strcpy(symbol->errtxt, "error: can't open output file");
		return 11;
	}
	
	/* Set up error handling routine as proc() above */
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, graphic,
		writepng_error_handler, NULL);
	if (!png_ptr) {
		strcpy(symbol->errtxt, "error: out of memory");
		return 11;
	}

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) {
		png_destroy_write_struct(&png_ptr, NULL);
		strcpy(symbol->errtxt, "error: out of memory");
		return 11;
	}

	/* catch jumping here */
	if (setjmp(graphic->jmpbuf)) {
		png_destroy_write_struct(&png_ptr, &info_ptr);
		strcpy(symbol->errtxt, "error: libpng error occurred");
		return 11;
	}

	/* open output file with libpng */
	png_init_io(png_ptr, graphic->outfile);

	/* set compression */
	png_set_compression_level(png_ptr, Z_BEST_COMPRESSION);

	/* set Header block */
	png_set_IHDR(png_ptr, info_ptr, graphic->width, graphic->height,
		8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
		PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);

	/* write all chunks up to (but not including) first IDAT */
	png_write_info(png_ptr, info_ptr);

	/* set up the transformations:  for now, just pack low-bit-depth pixels
	   into bytes (one, two or four pixels per byte) */
	png_set_packing(png_ptr);

	/* set rowbytes - depends on picture depth */
	rowbytes = wpng_info.width * 3;

	/* Pixel Plotting */
	offset = symbol->border_width + symbol->whitespace_width;
	for (j = 0;  j < graphic->height;  j++) {

		/* top border */
		if (j < symbol->border_width) {
			if ((symbol->output_options == BARCODE_BOX) || (symbol->output_options == BARCODE_BIND)) {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = fgred;
					outdata[i + 1] = fggrn;
					outdata[i + 2] = fgblu;
				}
			} else {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}
			}
		}

		/* middle section */
		if ((j >= symbol->border_width) && (j < (graphic->height - symbol->border_width))) {
			for(i = 0; i < (graphic->width * 3); i+= 3) {
				k = (i / 3);

				/* left hand border */
				if(k < symbol->border_width) {
					if(symbol->output_options == BARCODE_BOX) {
						outdata[i] = fgred;
						outdata[i + 1] = fggrn;
						outdata[i + 2] = fgblu;
					} else {
						outdata[i] = bgred;
						outdata[i + 1] = bggrn;
						outdata[i + 2] = bgblu;
					}
				}

				/* left whitespace */
				if((k >= symbol->border_width) && (k < (symbol->border_width + symbol->whitespace_width))) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}

				/* the symbol area */
				if((k >= (symbol->border_width + symbol->whitespace_width)) && (k < (graphic->width - (symbol->border_width + symbol->whitespace_width)))) {
					int row_height;

					row =  (j - symbol->border_width) / ((graphic->height - (symbol->border_width * 2)) / symbol->rows);
					if(symbol->encoded_data[row][(k - offset) / 2] == '1') {
						outdata[i] = fgred;
						outdata[i + 1] = fggrn;
						outdata[i + 2] = fgblu;
					} else {
						outdata[i] = bgred;
						outdata[i + 1] = bggrn;
						outdata[i + 2] = bgblu;
					}

					/* row binding */
					if(row_binding) {
						row_height = (graphic->height - (2 * symbol->border_width)) / symbol->rows;
						if (j == (((row * row_height) + symbol->border_width) - 2)) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
						if (j == (((row * row_height) + symbol->border_width) - 1)) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
						if (j == (row * row_height) + symbol->border_width) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
						if (j == (((row * row_height) + symbol->border_width) + 1)) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
					}
				}

				/* right whitespace */
				if((k >= (graphic->width - (symbol->border_width + symbol->whitespace_width))) && (k < (graphic->width - symbol->border_width))) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}

				/* right hand border */
				if(k >= (graphic->width - symbol->border_width)) {
					if(symbol->output_options == BARCODE_BOX) {
						outdata[i] = fgred;
						outdata[i + 1] = fggrn;
						outdata[i + 2] = fgblu;
					} else {
						outdata[i] = bgred;
						outdata[i + 1] = bggrn;
						outdata[i + 2] = bgblu;
					}
				}
			}
		}

		/* bottom border */
		if (j >= (graphic->height - symbol->border_width)) {
			if ((symbol->output_options == BARCODE_BOX) || (symbol->output_options == BARCODE_BIND)) {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = fgred;
					outdata[i + 1] = fggrn;
					outdata[i + 2] = fgblu;
				}
			} else {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}
			}
		}

		/* write row contents to file */
		image_data = outdata;
		png_write_row(png_ptr, image_data);
	}

	/* End the file */
	png_write_end(png_ptr, NULL);

	/* make sure we have disengaged */
	if (png_ptr && info_ptr) png_destroy_write_struct(&png_ptr, &info_ptr);
	fclose(wpng_info.outfile);

	return 0;
}
