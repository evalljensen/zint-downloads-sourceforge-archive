/* qr.c Handles QR Code by utilising libqrencode */

/*  Zint - A barcode generating library
    Copyright (C) 2007 Robin Stuart
    Copyright (C) 2006 Kentaro Fukuchi <fukuchi@megaui.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string.h>
#include <qrencode.h> /* The assumption is that this is already installed */
#include "common.h"

static int casesensitive = 0;
static int kanji = 0;
static int version = 0;
static int size = 3;
static int margin = 4;
static QRecLevel level = QR_ECLEVEL_L;

QRcode *encode(const char *intext)
{
	QRencodeMode hint;
	QRcode *code;

	if(kanji) {
		hint = QR_MODE_KANJI;
	} else {
		hint = QR_MODE_8;
	}

	if(casesensitive) {
		code = QRcode_encodeStringCase(intext, version, level);
	} else {
		code = QRcode_encodeString(intext, version, level, hint);
	}

	return code;
}

int qr_code(struct zint_symbol *symbol, char source[])
{
	QRcode *code;
	int errno = 0;
	int i, j;
	
	code = encode(source);
	if(code == NULL) {
		strcpy(symbol->errtxt, "error: libqrencode failed to encode the input data");
		return 11;
	}
	
	symbol->width = code->width;
	symbol->rows = code->width;
	
	for(i = 0; i < code->width; i++) {
		for(j = 0; j < code->width; j++) {
			if((*(code->data + (i * code->width) + j) & 0x01) == 0) {
				symbol->encoded_data[i][j] = '0';
			} else {
				symbol->encoded_data[i][j] = '1';
			}
		}
	}
	
	QRcode_free(code);
	
	return errno;
}
