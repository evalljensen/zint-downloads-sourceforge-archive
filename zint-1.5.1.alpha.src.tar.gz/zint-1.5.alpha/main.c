/* main.c - Command line handling routines for Zint */

/*  Zint - A barcode generating program using libzint
    Copyright (C) 2007 Robin Stuart

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <zint.h>

#define NESET "0123456789"

void usage(void)
{
	printf(
		"Zint version 1.5\n"
		"Encode input data in a barcode and save as a PNG image.\n\n"
		"  -h, --help            Display this message.\n"
		"  -o, --output=FILE     Write PNG image to FILE. (default is out.png)\n"
		"  -d, --data=DATA       Barcode content.\n"
		"  -b, --barcode=NUMBER  Number of barcode type (default is 20 (=Code128)).\n"
		"  -h, --height=HEIGHT   Height of symbol in pixels.\n"
		"  -w, --whitesp=NUMBER  Width of whitespace in pixels.\n"
		"  --border=NUMBER       Width of border in pixels.\n"
		"  --box                 Add a box.\n"
		"  --bind                Add boundary bars.\n"
		"  -r, --reverse         Reverse colours (white on black).\n"
		"  --fg=COLOUR           Specify a foreground colour.\n"
		"  --bg=COLOUR           Specify a background colour.\n"
		"  --cols=NUMBER         (PDF417) Number of columns.\n"
		"  --secure=NUMBER       (PDF417) Error correction level.\n"
	);
}

void prescan(char input[])
{ /* Handles escape characters with the | character - this allows support for the
	full ASCII character set (except NULL), and also for characters which are usually
	reserved for wildcards in bash. This function simply replaces the characters in the
	string with the correct ones */
	
	char output[1000];
	int reader = 0;
	int writer = 0;

	do {
		if(input[reader] == '|') {
			switch(input[reader + 1]) {
				case 'h': output[writer] = 1; break; /* SOH (start of heading) */
				case 'S': output[writer] = 2; break; /*  STX (start of text) */
				case 'E': output[writer] = 3; break; /*  ETX (end of text) */
				case 'z': output[writer] = 4; break; /*  EOT (end of transmission) */
				case 'q': output[writer] = 5; break; /*  ENQ (enquiry) */
				case 'k': output[writer] = 6; break; /*  ACK (acknowledge) */
				case 'b': output[writer] = 7; break; /*  BEL (bell) */
				case 'B': output[writer] = 8; break; /*  BS  (backspace) */
				case 't': output[writer] = 9; break; /*  TAB (horizontal tab) */
				case 'n': output[writer] = 10; break; /*  LF  (new line / line feed) */
				case 'v': output[writer] = 11; break; /*  VT  (vertical tab) */
				case 'p': output[writer] = 12; break; /*  FF  (form feed / new page) */
				case 'c': output[writer] = 13; break; /*  CR  (carriage return) */
				case 'o': output[writer] = 14; break; /*  SO  (shift out) */
				case 'i': output[writer] = 15; break; /*  SI  (shift in) */
				case 'L': output[writer] = 16; break; /*  DLE (data link escape) */
				case '1': output[writer] = 17; break; /*  DC1 (device control 1) */
				case '2': output[writer] = 18; break; /*  DC2 (device control 2) */
				case '3': output[writer] = 19; break; /*  DC3 (device control 3) */
				case '4': output[writer] = 20; break; /*  DC4 (device control 4) */
				case 'N': output[writer] = 21; break; /*  NAK (negative acknowledge) */
				case 'I': output[writer] = 22; break; /*  SYN (synchronous idle) */
				case 'T': output[writer] = 23; break; /*  ETB (end of trans. block) */
				case 'x': output[writer] = 24; break; /*  CAN (cancel) */
				case 'm': output[writer] = 25; break; /*  EM  (end of medium) */
				case 's': output[writer] = 26; break; /*  SUB (substitute) */
				case 'e': output[writer] = 27; break; /*  ESC (escape) */
				case 'f': output[writer] = 28; break; /*  FS  (file separator) */
				case 'g': output[writer] = 29; break; /*  GS  (group separator) */
				case 'r': output[writer] = 30; break; /*  RS  (record separator) */
				case 'u': output[writer] = 31; break; /*  US  (unit separator) */
				case 'Q': output[writer] = '!'; break; /* exclamation */
				case 'W': output[writer] = '\"'; break; /* double speech mark */
				case 'K': output[writer] = '\''; break; /* single speech mark */
				case 'U': output[writer] = '*'; break; /* asterisk */
				case 'M': output[writer] = '?'; break; /* question mark */
				case '|': output[writer] = '|'; break; /* bar */
				case 'd': output[writer] = 127; break; /*  DEL (delete) */
			}
			writer++;
			reader += 2;
		} else {
			output[writer] = input[reader];
			writer++;
			reader++;
		}
	} while (reader <= strlen(input));

	for (reader = 0; reader <= strlen(output); reader++) {
		input[reader] = output[reader];
	}
}

int main(int argc, char **argv)
{
	struct zint_symbol *symbol;
	int i, mode, stack_row;
	char *inputfile;
	int c;
	int errno;
	
	errno = 0;
	symbol = ZBarcode_Create();

	if(argc == 1) {
		usage();
		exit(1);
	}

	while(1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"help", 0, 0, 'h'},
			{"bind", 0, 0, 0},
			{"box", 0, 0, 0},
			{"barcode=", 1, 0, 'b'},
			{"height=", 1, 0, 0},
			{"whitesp=", 1, 0, 'w'},
			{"boder=", 0, 0, 0},
			{"data=", 1, 0, 'd'},
			{"output=", 1, 0, 'o'},
			{"input=", 1, 0, 'i'},
			{"fg=", 1, 0, 0},
			{"bg=", 1, 0, 0},
			{"cols=", 1, 0, 0},
			{"secure=", 1, 0, 0},
			{"reverse", 1, 0, 'r'},
			{0, 0, 0, 0}
		};
		c = getopt_long(argc, argv, "hb:w:d:o:i:r", long_options, &option_index);
		if(c == -1) break;

		switch(c) {
			case 0:
				if(!strcmp(long_options[option_index].name, "bind")) {
					symbol->output_options = BARCODE_BIND;
				}
				if(!strcmp(long_options[option_index].name, "box")) {
					symbol->output_options = BARCODE_BOX;
				}
				if(!strcmp(long_options[option_index].name, "fg=")) {
					strncpy(symbol->fgcolour, optarg, 7);
				}
				if(!strcmp(long_options[option_index].name, "bg=")) {
					strncpy(symbol->bgcolour, optarg, 7);
				}
				if(!strcmp(long_options[option_index].name, "border=")) {
					errno = is_sane(NESET, optarg);
					if((atoi(optarg) >= 0) && (atoi(optarg) <= 1000)) {
						symbol->border_width = atoi(optarg);
					} else {
						fprintf(stderr, "error: border width out of range\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "height=")) {
					errno = is_sane(NESET, optarg);
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 1000)) {
						symbol->height = atoi(optarg);
					} else {
						fprintf(stderr, "error: symbol height out of range\n");
					}
				}

				if(!strcmp(long_options[option_index].name, "cols=")) {
					errno = is_sane(NESET, optarg);
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 30)) {
						symbol->pdf_width = atoi(optarg);
					} else {
						fprintf(stderr, "error: number of columns out of range\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "secure=")) {
					errno = is_sane(NESET, optarg);
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 8)) {
						symbol->pdf_secure = atoi(optarg);
					} else {
						fprintf(stderr, "error: error correction level out of range\n");
					}
				}
				break;
				
			case 'h':
				usage();
				break;
				
			case 'b':
				errno = is_sane(NESET, optarg);
				if(errno == 7) {
					printf("error: invalid barcode type\n");
					exit(1);
				}
				symbol->symbology = atoi(optarg);
				break;
				
			case 'w':
				errno = is_sane(NESET, optarg);
				if(errno == 7) {
					printf("error: invalid whitespace value\n");
					exit(1);
				}
				if((atoi(optarg) >= 0) && (atoi(optarg) <= 1000)) {
					symbol->whitespace_width = atoi(optarg);
				} else {
					fprintf(stderr, "error: whitespace value out of range");
				}
				break;
				
			case 'd': /* we have some data! */
				if(strlen(optarg) < 900) {
					if(ZBarcode_Encode_and_Print(symbol, optarg) != 0) {
						printf("%s\n", symbol->errtxt);
						exit(1);
					}
				} else {
					printf("error: input too long");
					exit(1);
				}
				break;
				
			case 'o':
				strncpy(symbol->outfile, optarg, 250);
				break;
				
			case 'i':
				strncpy(inputfile, optarg, 250);
				break;
				
			case 'r':
				strcpy(symbol->fgcolour, "ffffff");
				strcpy(symbol->bgcolour, "000000");
				break;
				
			case '?':
				break;
				
			default:
				printf("?? getopt error 0%o\n", c);
		}
	}
	
	if (optind < argc) {
		printf("Invalid option ");
		while (optind < argc)
			printf("%s", argv[optind++]);
		printf("\n");
	}
	
	/*
	if(((mode == PDF417) || (mode == PDF417TRUNC)) && (lock == FALSE)) {
		-- input from a file is required --
		pdf417enc(seclevel, colnum, &symbol, "", inputfile, mode, out_type);
	}
	if((mode == DATAMATRIX) && (lock == FALSE)) {
		-- Data Matrix input from file --
		dmatrix(&symbol, "", matrix_ecc, inputfile, matrix_size);
} 
	
	if((symbol.max_width != 0) && (out_type == PNG)) {
		-- some kind of encoding took place and there is data in the structure --
		png_plot(&symbol);
	}

	if((symbol.max_width != 0) && (out_type == FONT) && (!((symbol.symbology_type == FOURSTATE) || (symbol.symbology_type == PDF)))) {
		font_plot(&symbol);
} */
	
	if(strcmp(symbol->errtxt, "")) {
		printf(symbol->errtxt);
		printf("\n");
	}
	
	ZBarcode_Delete(symbol);
	
	return errno;
}
