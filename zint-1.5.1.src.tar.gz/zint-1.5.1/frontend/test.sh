echo testing Code 11
zint -o bar01.png -b 1 --height=50 -d 87654321
zint -o bar01.eps -b 1 --height=50 -d 87654321
echo testing Code 2 of 5 Standard
zint -o bar02.png -b 2 --height=50 -d 87654321
zint -o bar02.eps -b 2 --height=50 -d 87654321
echo testing Interleaved 2 of 5
zint -o bar03.png -b 3 --height=50 -d 87654321
zint -o bar03.eps -b 3 --height=50 -d 87654321
echo testing Code 2 of 5 IATA
zint -o bar04.png -b 4 --height=50 -d 87654321
zint -o bar04.eps -b 4 --height=50 -d 87654321
echo testing Code 2 of 5 Data Logic
zint -o bar06.png -b 6 --height=50 -d 87654321
zint -o bar06.eps -b 6 --height=50 -d 87654321
echo testing Code 2 of 5 Industrial
zint -o bar07.png -b 7 --height=50 -d 87654321
zint -o bar07.eps -b 7 --height=50 -d 87654321
echo testing Code 39
zint -o bar08.png -b 8 --height=50 -d CODE39
zint -o bar08.eps -b 8 --height=50 -d CODE39
echo testing Extended Code 39
zint -o bar09.png -b 9 --height=50 -d 'Code 39e'
zint -o bar09.eps -b 9 --height=50 -d 'Code 39e'
echo testing EAN8
zint -o bar10.png -b 13 --height=50 -d 7654321
zint -o bar10.eps -b 13 --height=50 -d 7654321
echo testing EAN8 - 2 digits add on
zint -o bar11.png -b 13 --height=50 -d 7654321+21
zint -o bar11.eps -b 13 --height=50 -d 7654321+21
echo testing EAN8 - 5 digits add-on
zint -o bar12.png -b 13 --height=50 -d 7654321+54321
zint -o bar12.eps -b 13 --height=50 -d 7654321+54321
echo testing EAN13
zint -o bar13.png -b 13 --height=50 -d 210987654321
zint -o bar13.eps -b 13 --height=50 -d 210987654321
echo testing EAN13 - 2 digits add-on
zint -o bar14.png -b 13 --height=50 -d 210987654321+21
zint -o bar14.eps -b 13 --height=50 -d 210987654321+21
echo testing EAN13 - 5 digits add-on
zint -o bar15.png -b 13 --height=50 -d 210987654321+54321
zint -o bar15.eps -b 13 --height=50 -d 210987654321+54321
echo testing EAN128
zint -o bar16.png -b 16 --height=50 -d 'EAN-128'
zint -o bar16.eps -b 16 --height=50 -d 'EAN-128'
echo testing CodaBar
zint -o bar18.png -b 18 --height=50 -d D765432C
zint -o bar18.eps -b 18 --height=50 -d D765432C
echo testing Code 128
zint -o bar20.png -b 20 --height=50 -d 'Code 128'
zint -o bar20.eps -b 20 --height=50 -d 'Code 128'
echo testing Extended Mode Code 128
zint -o barx20.png -b 20 --height=50 -d 'C�d 128'
zint -o barx20.eps -b 20 --height=50 -d 'C�d 128'
echo testing Deutshe Post Leitcode
zint -o bar21.png -b 21 --height=50 -d 3210987654321
zint -o bar21.eps -b 21 --height=50 -d 3210987654321
echo testing Deutche Post Identcode
zint -o bar22.png -b 22 --height=50 -d 10987654321
zint -o bar22.eps -b 22 --height=50 -d 10987654321
echo testing Code 16k
zint -o bar23.png -b 23 --height=50 -d 'Code 16k is a stacked symbology'
zint -o bar23.eps -b 23 --height=50 -d 'Code 16k is a stacked symbology'
echo testing Code 93
zint -o bar25.png -b 25 --height=50 -d 'Code 93'
zint -o bar25.eps -b 25 --height=50 -d 'Code 93'
echo testing Flattermarken
zint -o bar28.png -b 28 --height=50 -d 87654321
zint -o bar28.eps -b 28 --height=50 -d 87654321
echo testing Telepen Alpha
zint -o bar32.png -b 32 --height=50 -d 'Telepen'
zint -o bar32.eps -b 32 --height=50 -d 'Telepen'
echo testing UPC A
zint -o bar34.png -b 34 --height=50 -d 10987654321
zint -o bar34.eps -b 34 --height=50 -d 10987654321
echo testing UPC A - 2 digit add-on
zint -o bar35.png -b 34 --height=50 -d 10987654321+21
zint -o bar35.eps -b 34 --height=50 -d 10987654321+21
echo testing UPC A - 5 digit add-on
zint -o bar36.png -b 36 --height=50 -d 10987654321+54321
zint -o bar36.eps -b 36 --height=50 -d 10987654321+54321
echo testing UPC E
zint -o bar37.png -b 37 --height=50 -d 654321
zint -o bar37.eps -b 37 --height=50 -d 654321
echo testing UPC E - 2 digit add-on
zint -o bar38.png -b 37 --height=50 -d 654321+21
zint -o bar38.eps -b 37 --height=50 -d 654321+21
echo testing UPC E - 5 digit add-on
zint -o bar39.png -b 37 --height=50 -d 654321+54321
zint -o bar39.eps -b 37 --height=50 -d 654321+54321
echo testing PostNet-6
zint -o bar41.png -b 40 -d 54321
zint -o bar41.eps -b 40 -d 54321
echo testing PostNet-10
zint -o bar43.png -b 40 -d 987654321
zint -o bar43.eps -b 40 -d 987654321
echo testing PostNet-12
zint -o bar45.png -b 40 -d 10987654321
zint -o bar45.eps -b 40 -d 10987654321
echo testing MSI Code
zint -o bar47.png -b 47 --height=50 -d 87654321
zint -o bar47.eps -b 47 --height=50 -d 87654321
echo testing FIM
zint -o bar49.png -b 49 --height=50 -d D
zint -o bar49.eps -b 49 --height=50 -d D
echo testing LOGMARS
zint -o bar50.png -b 50 --height=50 -d LOGMARS
zint -o bar50.eps -b 50 --height=50 -d LOGMARS
echo testing Pharmacode One-Track
zint -o bar51.png -b 51 --height=50 -d 123456
zint -o bar51.eps -b 51 --height=50 -d 123456
echo testing Pharmazentralnumber
zint -o bar52.png -b 52 --height=50 -d 654321
zint -o bar52.eps -b 52 --height=50 -d 654321
echo testing Pharmacode Two-Track
zint -o bar53.png -b 53 --height=50 -d 12345678
zint -o bar53.eps -b 53 --height=50 -d 12345678
echo testing PDF417
zint -o bar55.png -b 55 -d 'PDF417 is a stacked symbology'
zint -o bar55.eps -b 55 -d 'PDF417 is a stacked symbology'
echo testing PDF417 Truncated
zint -o bar56.png -b 56 -d 'PDF417 is a stacked symbology'
zint -o bar56.eps -b 56 -d 'PDF417 is a stacked symbology'
echo testing QR Code
zint -o bar58.png -b 58 -d 'QR Code is a matrix symbology'
zint -o bar58.eps -b 58 -d 'QR Code is a matrix symbology'
echo testing Code 128 Subset B
zint -o bar60.png -b 60 --height=50 -d 87654321
zint -o bar60.eps -b 60 --height=50 -d 87654321
echo testing Australian Post Standard Customer
zint -o bar63.png -b 63 -d 87654321
zint -o bar63.eps -b 63 -d 87654321
echo testing Australian Post Customer 2
zint -o bar64.png -b 63 -d 87654321AUSPS
zint -o bar64.eps -b 63 -d 87654321AUSPS
echo testing Australian Post Customer 3
zint -o bar65.png -b 63 -d '87654321 AUSTRALIA'
zint -o bar65.eps -b 63 -d '87654321 AUSTRALIA'
echo testing Australian Post Reply Paid
zint -o bar66.png -b 66 -d 87654321
zint -o bar66.eps -b 66 -d 87654321
echo testing Australian Post Routing
zint -o bar67.png -b 67 -d 87654321
zint -o bar67.eps -b 67 -d 87654321
echo testing Australian Post Redirection
zint -o bar68.png -b 68 -d 87654321
zint -o bar68.eps -b 68 -d 87654321
echo testing ISBN Code
zint -o bar69.png -b 69 --height=50 -d 0333638514
zint -o bar69.eps -b 69 --height=50 -d 0333638514
echo testing Royal Mail 4 State
zint -o bar70.png -b 70 -d ROYALMAIL
zint -o bar70.eps -b 70 -d ROYALMAIL
echo testing Data Matrix
zint -o bar71.png -b 71 -d 'Data Matrix is a matrix symbology'
zint -o bar71.eps -b 71 -d 'Data Matrix is a matrix symbology'
echo testing EAN-14
zint -o bar72.png -b 72 --height=50 -d 3210987654321
zint -o bar72.eps -b 72 --height=50 -d 3210987654321
echo testing NVE-18
zint -o bar75.png -b 75 --height=50 -d 76543210987654321
zint -o bar75.eps -b 75 --height=50 -d 76543210987654321
echo testing Planet 12 Digit
zint -o bar82.png -b 82 -d 10987654321
zint -o bar82.eps -b 82 -d 10987654321
echo testing Planet 14 Digit
zint -o bar83.png -b 82 -d 3210987654321
zint -o bar83.eps -b 82 -d 3210987654321
echo testing Micro PDF417
zint -o bar84.png -b 84 -d 'MicroPDF417 is a very small stacked symbology'
zint -o bar84.eps -b 84 -d 'MicroPDF417 is a very small stacked symbology'
echo testing USPS OneCode 4-State Customer Barcode
zint -o bar85.png -b 85 -d 01234567094987654321
zint -o bar85.eps -b 85 -d 01234567094987654321
echo testing Plessey Code with bidirectional reading support
zint -o bar86.png -b 86 --height=50 -d 87654321
zint -o bar86.eps -b 86 --height=50 -d 87654321
echo testing Telepen Numeric
zint -o bar100.png -b 100 --height=50 -d 87654321
zint -o bar100.eps -b 100 --height=50 -d 87654321
echo testing MSI Plessey with Mod-10 check
zint -o bar101.png -b 101 --height=50 -d 87654321
zint -o bar101.eps -b 101 --height=50 -d 87654321
echo testing MSI Plessey with 2 x Mod-10 checks
zint -o bar102.png -b 102 --height=50 -d 87654321
zint -o bar102.eps -b 102 --height=50 -d 87654321
echo testing MSI Plessey with Mod-11 check
zint -o bar103.png -b 103 --height=50 -d 87654321
zint -o bar103.eps -b 103 --height=50 -d 87654321
echo testing MSI Plessey with Mod-10 and Mod-11 check
zint -o bar104.png -b 104 --height=50 -d 87654321
zint -o bar104.eps -b 104 --height=50 -d 87654321
echo testing Code 39 with Modulo 43 check
zint -o bar105.png -b 105 --height=50 -d 'CODE 39 MOD 43'
zint -o bar105.eps -b 105 --height=50 -d 'CODE 39 MOD 43'
echo testing Extended Code 39 with Modulo 43 check
zint -o bar106.png -b 106 --height=50 -d 'Code 39e MOD 43'
zint -o bar106.eps -b 106 --height=50 -d 'Code 39e MOD 43'