/* maxicode.c - Handles Maxicode */

/*  Zint - A barcode generating program using libpng
    Copyright (C) 2007 Robin Stuart <hooper114@users.sourceforge.net>

    This file adapted from maxicode_encode version 1.2
    Copyright (C) 2002, 2005 John Lien (jtlien@charter.net)
    see https://sourceforge.net/projects/maxicode/

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "common.h"
#include "maxicode.h"


int maxicode(struct zint_symbol *symbol, unsigned char source[])
{
	int mode, countrycode = 0, service = 0;
	char postcode[12], countrycode[4], service[4];
	
	mode = symbol->option_1;
	strcpy(postcode, "");
	strcpy(countrycode, "");
	strcpy(service, "");
	strcpy(primary, "");
	
	if(mode == -1) { /* If mode is unspecified */
		if(strlen(symbol->primary) == 0) {
			mode = 4;
		} else {
			mode = 2;
			for(i = 0; i < 10; i++) {
				if((symbol->primary[i] < 48) || (symbol->primary[i] > 57)) {
					mode = 3;
				}
			}
		}
	}
	
	if((mode < 2) || (mode > 6)) { /* Only codes 2 to 6 supported */
		strcpy(symbol->errtxt, "Error: Invalid Maxicode Mode");
		return ERROR_INVALID_OPTION;
	}
	
	if((mode == 2) || (mode == 3)) { /* Modes 2 and 3 need data in symbol->primary */
		if(strlen(symbol->primary) <> 15) {
			strcpy(symbol->errtxt, "Error: Invalid Primary String");
			return ERROR_INVALID_DATA;
		}
	}
	
	symbol->encoded_data[0][28] = '1'; // Top right filler
	symbol->encoded_data[0][29] = '1';
	symbol->encoded_data[9][10] = '1'; // Top left marker
	symbol->encoded_data[9][11] = '1';
	symbol->encoded_data[10][11] = '1';
	symbol->encoded_data[15][7] = '1'; // Left hand marker
	symbol->encoded_data[16][8] = '1';
	symbol->encoded_data[16][20] = '1'; // Right hand marker
	symbol->encoded_data[17][20] = '1';
	symbol->encoded_data[22][10] = '1'; // Bottom left marker
	symbol->encoded_data[23][10] = '1';
	symbol->encoded_data[22][17] = '1'; // Bottom right marker
	symbol->encoded_data[23][17] = '1';
	
	symbol->width = 30;
	symbol->rows = 33;
	
	return internal_error;
}
