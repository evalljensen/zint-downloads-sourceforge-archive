/* main.c - Command line handling routines for Zint */

/*  Zint - A barcode generating program using libzint
    Copyright (C) 2007 Robin Stuart <hooper114@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <zint.h>

#define NESET "0123456789"

void usage(void)
{
	printf(
		"Zint version %s\n"
		"Encode input data in a barcode and save as a PNG image.\n\n"
		"  -h, --help            Display this message.\n"
		"  -o, --output=FILE     Write image to FILE. (default is out.png)\n"
		"  -d, --data=DATA       Barcode content.\n"
		"  -b, --barcode=NUMBER  Number of barcode type (default is 20 (=Code128)).\n"
		"  --height=HEIGHT       Height of my_symbol in pixels.\n"
		"  -w, --whitesp=NUMBER  Width of whitespace in pixels.\n"
		"  --border=NUMBER       Width of border in pixels.\n"
		"  --box                 Add a box.\n"
		"  --bind                Add boundary bars.\n"
		"  -r, --reverse         Reverse colours (white on black).\n"
		"  --fg=COLOUR           Specify a foreground colour.\n"
		"  --bg=COLOUR           Specify a background colour.\n"
		"  --cols=NUMBER         (PDF417) Number of columns.\n"
		"  --secure=NUMBER       (PDF417) Error correction level.\n"
		"  -c, --case            (QR Code) Set case sensitive mode (default is case insensitive).\n"
		"  --primary=STRING      (Maxicode) Structured primary message.\n"
		"  --mode=NUMBER         (Maxicode) Set encodind mode (4 - 6).\n"
	, VERSION);
}

int main(int argc, char **argv)
{
	struct zint_symbol *my_symbol;
	int i, mode, stack_row;
	int c;
	int errornum;
	
	errornum = 0;
	my_symbol = ZBarcode_Create();

	if(argc == 1) {
		usage();
		exit(1);
	}

	while(1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"help", 0, 0, 'h'},
			{"bind", 0, 0, 0},
			{"box", 0, 0, 0},
			{"barcode=", 1, 0, 'b'},
			{"height=", 1, 0, 0},
			{"whitesp=", 1, 0, 'w'},
			{"border=", 1, 0, 0},
			{"data=", 1, 0, 'd'},
			{"output=", 1, 0, 'o'},
			{"fg=", 1, 0, 0},
			{"bg=", 1, 0, 0},
			{"cols=", 1, 0, 0},
			{"secure=", 1, 0, 0},
			{"reverse", 1, 0, 'r'},
			{"case", 0, 0, 'c'},
			{"mode=", 1, 0, 0},
			{"primary=", 1, 0, 0},
			{0, 0, 0, 0}
		};
		c = getopt_long(argc, argv, "hb:w:d:o:i:rcmp", long_options, &option_index);
		if(c == -1) break;

		switch(c) {
			case 0:
				if(!strcmp(long_options[option_index].name, "bind")) {
					my_symbol->output_options = BARCODE_BIND;
				}
				if(!strcmp(long_options[option_index].name, "box")) {
					my_symbol->output_options = BARCODE_BOX;
				}
				if(!strcmp(long_options[option_index].name, "fg=")) {
					strncpy(my_symbol->fgcolour, optarg, 7);
				}
				if(!strcmp(long_options[option_index].name, "bg=")) {
					strncpy(my_symbol->bgcolour, optarg, 7);
				}
				if(!strcmp(long_options[option_index].name, "border=")) {
					errornum = is_sane(NESET, optarg);
					if(errornum == ERROR_INVALID_DATA) {
						fprintf(stderr, "error: invalid border width\n");
						exit(1);
					}
					if((atoi(optarg) >= 0) && (atoi(optarg) <= 1000)) {
						my_symbol->border_width = atoi(optarg);
					} else {
						fprintf(stderr, "error: border width out of range\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "height=")) {
					errornum = is_sane(NESET, optarg);
					if(errornum == ERROR_INVALID_DATA) {
						fprintf(stderr, "error: invalid height\n");
						exit(1);
					}
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 1000)) {
						my_symbol->height = atoi(optarg);
					} else {
						fprintf(stderr, "error: my_symbol height out of range\n");
					}
				}

				if(!strcmp(long_options[option_index].name, "cols=")) {
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 30)) {
						my_symbol->option_2 = atoi(optarg);
					} else {
						fprintf(stderr, "error: number of columns out of range\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "secure=")) {
					if((atoi(optarg) >= 1) && (atoi(optarg) <= 8)) {
						my_symbol->option_1 = atoi(optarg);
					} else {
						fprintf(stderr, "error: error correction level out of range\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "primary=")) {
					if(strlen(optarg) <= 90) {
						strcpy(my_symbol->primary, optarg);
					} else {
						fprintf(stderr, "error: primary string too long\n");
					}
				}
				if(!strcmp(long_options[option_index].name, "mode=")) {
					/* Don't allow specification of modes 2 and 3 - do it
					automagically instead */
					if((optarg[0] >= 52) && (optarg[0] <= 54)) {
						my_symbol->option_1 = optarg[0] - 48;
					}
				break;
				
			case 'h':
				usage();
				break;
				
			case 'b':
				errornum = is_sane(NESET, optarg);
				if(errornum == ERROR_INVALID_DATA) {
					printf("error: invalid barcode type\n");
					exit(1);
				}
				my_symbol->symbology = atoi(optarg);
				break;
				
			case 'w':
				errornum = is_sane(NESET, optarg);
				if(errornum == ERROR_INVALID_DATA) {
					printf("error: invalid whitespace value\n");
					exit(1);
				}
				if((atoi(optarg) >= 0) && (atoi(optarg) <= 1000)) {
					my_symbol->whitespace_width = atoi(optarg);
				} else {
					fprintf(stderr, "error: whitespace value out of range");
				}
				break;
				
			case 'd': /* we have some data! */
				if(ZBarcode_Encode_and_Print(my_symbol, optarg) != 0) {
					printf("%s\n", my_symbol->errtxt);
					return 1;
				}
				break;
				
			case 'o':
				strncpy(my_symbol->outfile, optarg, 250);
				break;
				
			case 'r':
				strcpy(my_symbol->fgcolour, "ffffff");
				strcpy(my_symbol->bgcolour, "000000");
				break;
			
			case 'c':
				my_symbol->option_1 = QR_CASE_SENSITIVE;
				break;
				
			case '?':
				break;
				
			default:
				printf("?? getopt error 0%o\n", c);
		}
	}
	
	if (optind < argc) {
		printf("Invalid option ");
		while (optind < argc)
			printf("%s", argv[optind++]);
		printf("\n");
	}
	
	if(strcmp(my_symbol->errtxt, "")) {
		printf(my_symbol->errtxt);
		printf("\n");
	}
	
	ZBarcode_Delete(my_symbol);
	
	return errornum;
}
