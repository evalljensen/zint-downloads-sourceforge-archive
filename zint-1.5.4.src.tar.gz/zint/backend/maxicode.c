/* maxicode.c - Handles Maxicode */

/*
    libzint - the open source barcode library
    Copyright (C) 2007 Robin Stuart <zint@hotmail.co.uk>

    Error correction code adapted from maxicode_encode version 1.2
    Copyright (C) 2002, 2005 John Lien (jtlien@charter.net)
    see https://sourceforge.net/projects/maxicode/

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* This code has been thoroughly checked against ISO/IEC 16023:2000 */

#include "common.h"
#include "maxicode.h"
#include <string.h>

#define BITMASK 0x3F

void maxi_generateEC( UInt32 *data, UInt32 len, UInt32 EClen)
{
	UInt32 base_reg[80]; 
	UInt32 coeff_reg[80];
	UInt32 i,j;
	int tint;
	UInt32 temp;
	UInt32 wrap;
	int debug;
    
	debug = 0;

	if (debug)
	{
		printf("In maxi_generateEC - len = %d EClen = %d \n", len, EClen);
		for(i=0; i < len; i += 1)
			printf("Data in = %d %d \n",i, data[i]);
		printf(" In maxi_generateEC - data length = %d \n",len);
		printf(" In maxi_generateEC - ECC length = %d \n",EClen);
	}

	/* get the coefficients */

	if ( EClen == 20)
	{
		for (i = 0; i < EClen; i +=1)
		{
			coeff_reg[i] = mods_20[i+1];
			if (debug) { printf("Set coeff_reg %d to %d \n", i, coeff_reg[i]); }
		}
	}

	if ( EClen == 28)
	{
		for (i = 0; i < EClen; i +=1)
		{
			coeff_reg[i] = mods_28[i+1];
			if (debug) { printf("Set coeff_reg %d to %d \n", i, coeff_reg[i]); }
		}
	}

	if (EClen == 10)
	{
		for (i = 0; i < EClen; i +=1)
		{
			coeff_reg[i] = mods_10[i+1];
			if (debug) { printf("Set coeff_reg %d to %d \n", i, coeff_reg[i]); }
		}
	}
 
	/* initialize b regs */

	for (i = 0; i < EClen; i +=1)
		base_reg[i]=0;

	/* Initialize ecc result data */
	for (i=len; i < len + EClen; i += 1)
		data[i] = 0;

	/* Load up with data */
	for(i=0;i<len;++i) 
	{
		wrap = (base_reg[EClen-1] ^ data[i]) & BITMASK;

		for (j=EClen-1; j > 0; j = j-1)
		{
			temp = maxi_poly_mult(coeff_reg[EClen-1-j], wrap) & BITMASK;
			base_reg[j] = (base_reg[j-1] ^ temp) & BITMASK;
		}
		temp = maxi_poly_mult(coeff_reg[EClen-1], wrap) & BITMASK;
		/* temp = (temp ^ BITMASK) & BITMASK; */
		base_reg[0]= temp;
	}

	/* Read off the info */

	for (j = 0; j < EClen; j += 1)
	{
		if (debug) printf("Adding ECC byte %d = %d \n",j,base_reg[EClen-1-j]);
		/*	  data[len+j] = base_reg[j]; */
		tint = base_reg[EClen-1-j];
		/* maxi_put_back(tint); */
		ecc_results[j] = tint;
	}
} /* maxi_generateEC */

void maxi_coeff_init_32()
{
	mods_10[0] = 1;
	mods_10[1] = 31;
	mods_10[2] = 28;
	mods_10[3] = 39;
	mods_10[4] = 42;
	mods_10[5] = 57;
	mods_10[6] = 2;
	mods_10[7] = 3;
	mods_10[8] = 49;
	mods_10[9] = 44;
	mods_10[10] = 46;

	mods_20[0] = 1;
	mods_20[1] = 23;
	mods_20[2] = 44;
	mods_20[3] = 11;
	mods_20[4] = 33;
	mods_20[5] = 27;
	mods_20[6] = 8;
	mods_20[7] = 22;
	mods_20[8] = 37;
	mods_20[9] = 57;
	mods_20[10] = 36;
	mods_20[11] = 15;
	mods_20[12] = 48;
	mods_20[13] = 22;
	mods_20[14] = 17;
	mods_20[15] = 38;
	mods_20[16] = 33;
	mods_20[17] = 31;
	mods_20[18] = 19;
	mods_20[19] = 23;
	mods_20[20] = 59;
  
	mods_28[0] = 1;
	mods_28[1] = 22;
	mods_28[2] = 45;
	mods_28[3] = 53;
	mods_28[4] = 10;
	mods_28[5] = 41;
	mods_28[6] = 55;
	mods_28[7] = 35;
	mods_28[8] = 10;
	mods_28[9] = 22;
	mods_28[10] = 29;
	mods_28[11] = 23;
	mods_28[12] = 13;
	mods_28[13] = 61;
	mods_28[14] = 45;
	mods_28[15] = 34;
	mods_28[16] = 55;
	mods_28[17] = 40;
	mods_28[18] = 37;
	mods_28[19] = 46;
	mods_28[20] = 49;
	mods_28[21] = 34;
	mods_28[22] = 41;
	mods_28[23] = 9;
	mods_28[24] = 43;
	mods_28[25] = 7;
	mods_28[26] = 20;
	mods_28[27] = 11;
	mods_28[28] = 28;

} /* end */

int maxi_modnn(int x)
{
	while (x >= NN) 
	{
		x -= NN;
		x = (x >> MM) + (x & NN);
	}
	return x;
}

void maxi_generate_gf(void)
{
	register int i, mask;
	int debug = 0;
	int Ppp[MM+1] = { 1, 1, 0, 0, 0, 0, 1 };

	debug = 0;

	mask = 1;
	Alpha_to[MM] = 0;
	for (i = 0; i < MM; i++) 
	{
		Alpha_to[i] = mask;
		Index_of[Alpha_to[i]] = i;
		/* If Ppp[i] == 1 then, term @^i occurs in poly-repr of @^MM */
		if (Ppp[i] != 0)
			Alpha_to[MM] ^= mask;	/* Bit-wise EXOR operation */
		mask <<= 1;	/* single left-shift */
	}
	Index_of[Alpha_to[MM]] = MM;
   /*
	* Have obtained poly-repr of @^MM. Poly-repr of @^(i+1) is given by
	* poly-repr of @^i shifted left one-bit and accounting for any @^MM
	* term that may occur when poly-repr of @^i is shifted.
   */
	mask >>= 1;
	for (i = MM + 1; i < NN; i++) 
	{
		if (Alpha_to[i - 1] >= mask)
			Alpha_to[i] = Alpha_to[MM] ^ ((Alpha_to[i - 1] ^ mask) << 1);
		else
			Alpha_to[i] = Alpha_to[i - 1] << 1;
		Index_of[Alpha_to[i]] = i;
	}
	Index_of[0] = A0;
	Alpha_to[NN] = 0;
	if (debug)
	{
		for(i = 0; i < 64; i += 1)
		{
			printf("Alpha_to[%d] = %d \n", i, Alpha_to[i]);
			printf("Index_of[%d] = %d \n", i, Index_of[i]);
		}
	}
	RS_init = 1;
}

/*
 * Obtain the generator polynomial of the TT-error correcting, length
 * NN=(2**MM -1) Reed Solomon code from the product of (X+@**(B0+i)), i = 0,
 * ... ,(2*TT-1)
 *
 * Examples:
 *
 * If B0 = 1, TT = 1. deg(g(x)) = 2*TT = 2.
 * g(x) = (x+@) (x+@**2)
 *
 * If B0 = 0, TT = 2. deg(g(x)) = 2*TT = 4.
 * g(x) = (x+1) (x+@) (x+@**2) (x+@**3)
 */
static void maxi_gen_poly(void)
{
	register int i, j;

	Gg[0] = 1;
	for (i = 0; i < NN - KK; i++) 
	{
		Gg[i+1] = 1;
      /*
		* Below multiply (Gg[0]+Gg[1]*x + ... +Gg[i]x^i) by
		* (@**(B0+i)*PRIM + x)
      */
		for (j = i; j > 0; j--)
			if (Gg[j] != 0)
				Gg[j] = Gg[j - 1] ^ Alpha_to[maxi_modnn((Index_of[Gg[j]]) + (B0 + i) *PRIM)];
		else
			Gg[j] = Gg[j - 1];
		/* Gg[0] can never be zero */
		Gg[0] = Alpha_to[maxi_modnn(Index_of[Gg[0]] + (B0 + i) * PRIM)];
	}
	/* convert Gg[] to index form for quicker encoding */
	for (i = 0; i <= NN - KK; i++)
		Gg[i] = Index_of[Gg[i]];
}

void maxi_init_rs()
{
	maxi_generate_gf();
	maxi_gen_poly();
}

 
/*
 * take the string of symbols in data[i], i=0..(k-1) and encode
 * systematically to produce NN-KK parity symbols in bb[0]..bb[NN-KK-1] data[]
 * is input and bb[] is output in polynomial form. Encoding is done by using
 * a feedback shift register with appropriate connections specified by the
 * elements of Gg[], which was generated above. Codeword is   c(X) =
 * data(X)*X**(NN-KK)+ b(X)
 */
int maxi_encode_rs(int data[KK], int bb[NN-KK])
{
	register int i, j;
	int feedback;

	/* Check for illegal input values */
	for(i=0;i<KK;i++)
		if(data[i] > NN)
			return -1;

  /*  if(!RS_init)
	maxi_init_rs(); */

	CLEAR(bb,NN-KK);

	for(i = KK - 1; i >= 0; i--) 
	{
		feedback = Index_of[data[i] ^ bb[NN - KK - 1]];
		if (feedback != A0) 
		{	/* feedback term is non-zero */
			for (j = NN - KK - 1; j > 0; j--)
				if (Gg[j] != A0)
					bb[j] = bb[j - 1] ^ Alpha_to[maxi_modnn(Gg[j] + feedback)];
			else
				bb[j] = bb[j - 1];
			bb[0] = Alpha_to[maxi_modnn(Gg[0] + feedback)];
		} 
		else 
		{  /* feedback term is zero. encoder becomes a
		   * single-byte shifter */
			for (j = NN - KK - 1; j > 0; j--)
				bb[j] = bb[j - 1];
			bb[0] = 0;
		}
	}
	return 0;
}
 

/*
 * Performs ERRORS+ERASURES decoding of RS codes. If decoding is successful,
 * writes the codeword into data[] itself. Otherwise data[] is unaltered.
 *
 * Return number of symbols corrected, or -1 if codeword is illegal
 * or uncorrectable. If eras_pos is non-null, the detected error locations
 * are written back. NOTE! This array must be at least NN-KK elements long.
 * 
 * First "no_eras" erasures are declared by the calling program. Then, the
 * maximum # of errors correctable is t_after_eras = floor((NN-KK-no_eras)/2).
 * If the number of channel errors is not greater than "t_after_eras" the
 * transmitted codeword will be recovered. Details of algorithm can be found
 * in R. Blahut's "Theory ... of Error-Correcting Codes".

 * Warning: the eras_pos[] array must not contain duplicate entries; decoder failure
 * will result. The decoder *could* check for this condition, but it would involve
 * extra time on every decoding operation.
 */
int maxi_eras_dec_rs(int data[NN], int eras_pos[NN-KK], int no_eras,int data_len, int synd_len)
{
	int deg_lambda, el, deg_omega;
	int i, j, r;
	int u,q,tmp,num1,num2,den,discr_r;
	int lambda[512 + 1], s[512 + 1];	/* Err+Eras Locator poly
						* and syndrome poly */
	int b[512 + 1], t[512 + 1], omega[512 + 1];
	int root[512], reg[512 + 1], loc[512];
	int syn_error, count;
	int fix_loc;
	int error_val;
	int mismatch;
	int debug = 0;
	int ci;
	int ato;

	if (!RS_init)
		maxi_init_rs();

	/* Check for illegal input values */
	for (i=0;i< data_len;i++)
		if (data[i] > GPRIME)
			return -1;
   /* form the maxi_syndromes; i.e., evaluate data(x) at roots of g(x)
	* namely @**(B0+i)*PRIM, i = 0, ... ,(NN-KK-1)
   */
	for (i=1;i<=synd_len;i++)
	{
		s[i] = data[data_len-1];
    
	}
	if (debug) 
		printf("data[data_len-1] = %d I_of same = %d \n", data[data_len-1] , Index_of[data[data_len-1]]);

	for (j=1;j<data_len;j++)
	{
		if (data[data_len-1-j] == 0)
			continue;
		tmp = Index_of[data[data_len-1-j]];
        
		if (debug)
			printf("Data[%d] = %d tmp = %d \n", data_len-j-1, data[data_len-j-1], tmp);

		/*	s[i] ^= Alpha_to[maxi_modnn(tmp + (B0+i-1)*j)]; */
		for(i=1;i<=synd_len;i++)
		{
			ato = Alpha_to[maxi_modnn(tmp+(i*j))];
			if ( debug) 
				printf("pre s[%d] = %d \n", i, s[i]);
			s[i] = (s[i] ^ Alpha_to[maxi_modnn(tmp + (i*j))]) ;
			if (debug) 
			{ 
				printf("s[%d] = %d \n",i,s[i]);
				printf("maxi_modnn = %d \n",maxi_modnn(tmp + (i*j))); 
				printf(" i = %d j = %d tmp = %d \n",i,j,tmp); 
				printf("ato = %d \n",ato); 
			}
		}
	}

	mismatch = FALSE;
	for ( j= 0; j < synd_len ; j += 1)
	{
		if ( s[j + 1] != synd_array[j])
		{
			if (debug)
			{
				printf("Syndrome mismatch j = %d s[j] = %d I_of s[j] = %d  synd_array[j] = %d \n",j, s[j+1],Index_of[s[j+1]], synd_array[j]);
				mismatch = TRUE;
			}
		}
	}

	if ( mismatch == FALSE)
	{
		if (debug)
			printf("Correct maxi_syndromes \n"); 
	}
	else
		printf("Syndrome mismatch \n");

	/* Convert maxi_syndromes to index form, checking for nonzero condition */
	syn_error = 0;
	for(i=1;i<=synd_len;i++)
	{
		syn_error |= s[i];
		s[i] = Index_of[s[i]];
	}

	if (!syn_error) 
	{
      /* if syndrome is zero, data[] is a codeword and there are no
		* errors to correct. So return data[] unmodified
      */
		count = 0;
		goto finish;
	}
   //  CLEAR(&lambda[1],NN-KK);

	for (ci=synd_len-1;ci >=0;ci--)
		lambda[ci+1] = 0;

	lambda[0] = 1;

	if (no_eras > 0) 
	{
		/* Init lambda to be the erasure locator polynomial */
		lambda[1] = Alpha_to[maxi_modnn(PRIM * eras_pos[0])];
		for (i = 1; i < no_eras; i++) 
		{
			u = maxi_modnn(PRIM*eras_pos[i]);
			for (j = i+1; j > 0; j--) 
			{
				tmp = Index_of[lambda[j - 1]];
				if (tmp != A0)
					lambda[j] ^= Alpha_to[maxi_modnn(u + tmp)];
			}
		}
#if DEBUG >= 1
         /* Test code that verifies the erasure locator polynomial just constructed
            Needed only for decoder debugging. */
  
         /* find roots of the erasure location polynomial */
         for (i=1;i<=no_eras;i++)
            reg[i] = Index_of[lambda[i]];
         count = 0;
	 for (i = 1,k=data_len-Ldec; i <= data_len + synd_len ; i++,k = maxi_modnn(data_len+k-Ldec)) 
	 {
		 q = 1;
		 for (j = 1; j <= no_eras; j++)
			 if (reg[j] != A0) 
		 {
			 reg[j] = maxi_modnn(reg[j] + j);
			 q ^= Alpha_to[reg[j]];
		 }
		 if (q != 0)
			 continue;

		 /* store root and error location number indices */
		 root[count] = i;
		 loc[count] = k;
		 count++;
	 }
	 if (count != no_eras) 
	 {
		 printf("\n lambda(x) is WRONG\n");
		 count = -1;
		 goto finish;
	 }
#if DEBUG >= 2
            printf("\n Erasure positions as determined by roots of Eras Loc Poly:\n");
            for (i = 0; i < count; i++)
		    printf("%d ", loc[i]);
	    printf("\n");
#endif
#endif
	}

	for(i=0;i<synd_len+1;i++)
		b[i] = Index_of[lambda[i]];

   /*
	* Begin Berlekamp-Massey algorithm to determine error+erasure
	* locator polynomial
   */
	r = no_eras;
	el = no_eras;
	if (debug) 
		printf("no_eras = %d \n",no_eras);

	while (++r <= synd_len) 
	{	/* r is the step number */
		/* Compute discrepancy at the r-th step in poly-form */
		discr_r = 0;
		for (i = 0; i < r; i++)
		{
			if ((lambda[i] != 0) && (s[r - i] != A0)) 
			{
				discr_r ^= Alpha_to[maxi_modnn(Index_of[lambda[i]] + s[r - i])];
				if (debug) 
					printf("discr_r = %d i = %d r = %d lambda[i] = %d s[r-i] = %d \n", discr_r, i, r, lambda[i], s[r-i] );
			}
		}
		discr_r = Index_of[discr_r];	/* Index form */
		if (debug) 
			printf("I_of[discr_r] = %d \n", discr_r);

		if (discr_r == A0) 
		{
			/* 2 lines below: B(x) <-- x*B(x) */
        //      COPYDOWN(&b[1],b,NN-KK);
			for(ci=synd_len-1;ci >=0;ci--)
				b[ci+1] = b[ci];
			b[0] = A0;
		} 
		else 
		{
			/* 7 lines below: T(x) <-- lambda(x) - discr_r*x*b(x) */
			t[0] = lambda[0];
			for (i = 0 ; i < synd_len; i++) 
			{
				if(b[i] != A0)
					t[i+1] = lambda[i+1] ^ Alpha_to[maxi_modnn(discr_r + b[i])];
				else
					t[i+1] = lambda[i+1];
			}
			if (2 * el <= r + no_eras - 1) 
			{
				el = r + no_eras - el;
           /*
				* 2 lines below: B(x) <-- inv(discr_r) *
				* lambda(x)
	   */
				for (i = 0; i <= synd_len; i++)
					b[i]=(lambda[i]==0) ? A0 : maxi_modnn(Index_of[lambda[i]] - discr_r + NN);
			} 
			else 
			{
				/* 2 lines below: B(x) <-- x*B(x) */
	         // COPYDOWN(&b[1],b,NN-KK);
				for(ci=synd_len-1;ci >=0;ci--)
					b[ci+1] = b[ci];
				b[0] = A0;
			}
         //  COPY(lambda,t,NN-KK+1);
			for(ci=synd_len;ci >=0;ci--)
			{
				lambda[ci] = t[ci];
				if (debug) 
					printf("ci = %d Lambda = %d i_of Lambda = %d \n", ci, t[ci], Index_of[t[ci]]);
			}
		}
	}

	/* Convert lambda to index form and compute deg(lambda(x)) */
	deg_lambda = 0;
	for (i=0;i<synd_len+1;i++)
	{
		lambda[i] = Index_of[lambda[i]];
		if(lambda[i] != A0)
			deg_lambda = i;
	}
  /*
	* Find roots of the error+erasure locator polynomial by Chien
	* Search
  */
  //  COPY(&reg[1],&lambda[1],NN-KK);

	for(ci=synd_len-1;ci >=0;ci--)
		reg[ci+1] = lambda[ci+1];

	count = 0;		/* Number of roots of lambda(x) */
	for (i = 1; i <= NN+1; i++) 
	{
		q = 1;
		for (j = deg_lambda; j > 0; j--)
		{
			if (debug) 
				printf(" Reg[j] = %d q = %d i = %d j=%d\n", reg[j], q, i, j );
			if (reg[j] != A0) 
			{
				reg[j] = maxi_modnn(reg[j] + j);
				q ^= Alpha_to[reg[j]];
			}
		}
		if (debug) 
			printf(" q after  = %d i = %d\n", q, i ); 
		if (q != 0)
			continue;
		/* store root (index-form) and error location number */
		root[count] = i;
 
		loc[count] = NN + 1 - i;

     /* If we've already found max possible roots,
		* abort the search to save time
     */
		if (++count == deg_lambda)
			break;
	}
	if (deg_lambda != count) 
	{
    /*
		* deg(lambda) unequal to number of roots => uncorrectable
		* error detected
    */
		count = -1;
		goto finish;
	}
   /*
	* Compute err+eras evaluator poly omega(x) = s(x)*lambda(x) (modulo
	* x**(NN-KK)). in index form. Also find deg(omega).
   */
	deg_omega = 0;
	for (i = 0; i < synd_len;i++)
	{
		tmp = 0;
		j = (deg_lambda < i) ? deg_lambda : i;
		for(;j >= 0; j--)
		{
			if ((s[i + 1 - j] != A0) && (lambda[j] != A0))
				tmp ^= Alpha_to[maxi_modnn(s[i + 1 - j] + lambda[j])];
		}
		if (tmp != 0)
			deg_omega = i;
		omega[i] = Index_of[tmp];
	}
	omega[synd_len] = A0;

  /*
	* Compute error values in poly-form. num1 = omega(inv(X(l))), num2 =
	* inv(X(l))**(B0-1) and den = lambda_pr(inv(X(l))) all in poly-form
  */
	for (j = count-1; j >=0; j--) 
	{
		num1 = 0;
		for (i = deg_omega; i >= 0; i--) 
		{
			if (omega[i] != A0)
				num1  ^= Alpha_to[maxi_modnn(omega[i] + i * root[j])];
		}
     // num2 = Alpha_to[maxi_modnn(root[j] * (B0 - 1) + NN)];
		num2 = 1;
		den = 0;
 
     // denominator if product of all (1 - Bj Bk) for k != j
     // if count = 1, then den = 1
     //  alternate way to find denominator...

     //    den  = 1;
     // for ( k = 0; k < count ; k += 1)
     //  {
     //	if ( k != j)
     //          {
     //             tmp = maxi_modnn( 0xff ^ Alpha_to[maxi_modnn(root[k] + root[j])]);
		//            
     //            den = Alpha_to[ maxi_modnn( Index_of[den]  + Index_of[tmp])];
     //	      }
     //  }

		/* lambda[i+1] for i even is the formal derivative lambda_pr of lambda[i] */
		for (i = min(deg_lambda,synd_len-1) & ~1; i >= 0; i -=2) 
			if (lambda[i+1] != A0)
				den ^= Alpha_to[maxi_modnn(lambda[i+1] + i * root[j])];

		if (den == 0) 
		{
#if DEBUG >= 1
            printf("\n ERROR: denominator = 0\n");
#endif
        /* Convert to dual- basis */
        count = -1;
        goto finish;
		}
		/* Apply error to data */
     //  if (num1 != 0) {
     //  data[loc[j]] ^= Alpha_to[maxi_modnn(Index_of[num1] + Index_of[num2] + GPRIME - Index_of[den])];
     //  }

		if (debug) 
			printf("Num1=%d I_of[num1]=%d num2=%d I_of[num2]=%d den=%d I_of[den]=%d \n",num1, Index_of[num1], num2, Index_of[num2], den, Index_of[den] );
		error_val = Alpha_to[maxi_modnn(Index_of[num1] + Index_of[num2] + NN - Index_of[den])];

		if (debug) 
		{ 
			printf("Error val = %d Index_of[error_val] = %d maxi_modnn = %d\n", error_val, Index_of[error_val], maxi_modnn(Index_of[num1] + Index_of[num2] + NN - Index_of[den])); 
			printf("Data[fixloc] = %d \n", data[data_len-loc[j]]);
		}

		/* Apply error to data */
		if (num1 != 0) 
		{
			if ( loc[j] < data_len + 1 )
			{
				fix_loc = data_len   - loc[j];
				if (debug) 
					printf("Fix loc = %d \n", fix_loc);
				if ( fix_loc < data_len + 1)
					data[fix_loc] = (data[fix_loc] ^ error_val);
			}
		}
	}

finish:
		if (eras_pos != NULL)
		for (i=0;i<count;i++)
		if (eras_pos!= NULL)
		eras_pos[i] = loc[i];
   return count;
}

int maxi_poly_mult( int mult1, int mult2)
{
	int log1;
	int log2;
	int logres;
	int debug;

	static int bin_expgood[] = // binary_to polynomial power ( log)
	{
		63,    // infinity
		0,    // 1
		1,    // 2
		6,    // 3
		2,    // 4
		12,   // 5
		7,    // 6
		26,   // 7
		3,    // 8
		32,   // 9
		13,   // 10
		35,   // 11
		8,    // 12
		48,   // 13
		27,   // 14
		18,   // 15
		4,    // 16
		24,   // 17
		33,   // 18
		16,   // 19
		14,   // 20
		52,   // 21
		36,   // 22
		54,   // 23
		9,    // 24
		45,   // 25
		49,   // 26
		38,   // 27
		28,   // 28
		41,   // 29
		19,   // 30
		56,   // 31
		5,    // 32
		62,   // 33
		25,   // 34
		11,   // 35
		34,   // 36
		31,   // 37
		17,   // 38
		47,   // 39
		15,   // 40
		23,   // 41
		53,   // 42
		51,   // 43
		37,   // 44
		44,   // 45
		55,   // 46
		40,   // 47
		10,   // 48
		61,   // 49
		46,   // 50
		30,   // 51
		50,   // 52
		22,   // 53
		39,   // 54
		43,   // 55
		29,   // 56
		60,   // 57
		42,   // 58
		21,   // 59
		20,   // 60
		59,   // 61
		57,   // 62
		58    // 63
	};

	//
   // Galois field 2^6 generated by 1 + x +  x^6
	//
   // x^ (index) = binary value at index
	//
	static int exp_bingood[] = // polynomial power to binary ( antilog)
	{    
		1,       2,        4,       8,      16,      32,       3,       6,      12,
		24,      48,      35,       5,      10,      20,      40,      19,      38,
		15,      30,      60,      59,      53,      41,      17,      34,       7,
		14,      28,      56,      51,      37,       9,      18,      36,      11,
		22,      44,      27,      54,      47,      29,      58,      55,      45,
		25,      50,      39,      13,      26,      52,      43,      21,      42,
		23,      46,      31,      62,      63,      61,      57,      49,      33,
		0
	};

	debug = 0;

	if ((mult1 > 63) || ( mult1 < 0))
	{
		printf("Internal error in maxi_poly_mult call\n");
		exit(0);
	}
	if (( mult2 > 63 ) || (mult2 < 0))
	{
		printf("Internal error in maxi_poly_mult call\n");
		exit(0);
	}
   
	if (( mult1 == 0 ) || (mult2 == 0))
	{
		if (debug) { printf("Returning 0 \n"); }
		return(0);
	}

	log1 = bin_expgood[ mult1];
	log2 = bin_expgood[ mult2];

	if (debug)
	{
		printf(" in poly mult - mult1 = %d mult2 = %d \n",
		       mult1, mult2);
		printf(" in poly mult  log1 = %d log2 = %d  \n",
		       log1, log2);
		printf("Log1 = %d log2 = %d log1 + log2 = %d \n",log1,log2, log1+log2 );
	}

	logres = ( log1 + log2 ) % 63;

	if (debug) { printf("logres = %d \n", logres ); }
 
	return(exp_bingood[logres]);
}

void maxi_do_secondary_chk_even(int ecclen )
{
	/* Handles error correction of even characters in secondary */
	int data[144];
	int j;
	int datalen = 36;

	if (ecclen == 20)
		datalen = 84;
   /*
	if (ecclen == 28)
	datalen = 36;
   */
	for(j = 0; j < datalen + 1; j += 1)
		if ((j % 2) ==  0)
			data[j/2] = maxi_codeword[j + 20];

	maxi_generateEC( data, datalen/2, ecclen);    

	for ( j = 0; j < (ecclen); j += 1)
		maxi_codeword[ datalen + (2 *j) + 20] = ecc_results[j];
}

//
//  do the primary ecc check , always use the enhanced error correction
//
void maxi_do_primary_check(  )
{
	/* Handles error correction of primary message */
	int data[144];
	int j;
	int datalen = 10;
	int ecclen = 10;
	int debug = 0;


	if (debug)
		printf("In maxi_do_primary_check \n");
 
	for(j = 0; j < datalen; j += 1)
		data[j] = maxi_codeword[j];
 
	maxi_generateEC( data, datalen, ecclen);

	for ( j = 0; j < ecclen; j += 1)
		maxi_codeword[ datalen + j] = ecc_results[j];

	for ( j = 0; j < ecclen ; j += 1)
		data[ datalen + j ] = ecc_results[j];
}

void maxi_do_secondary_chk_odd( int ecclen )
{
	/* Handles error correction of odd characters in secondary */
	int data[144];
	int j;
	int datalen = 68;

	if (ecclen == 20)
		datalen = 84;

   /* if (ecclen == 28)
	datalen = 68; */

	for(j = 0; j < datalen; j += 1)
		if ((j % 2) ==  1)  // odd
			data[(j-1)/2] = maxi_codeword[j + 20];

	maxi_generateEC( data, datalen/2, ecclen);

	for ( j = 0; j < (ecclen); j += 1)
		maxi_codeword[ datalen + (2 *j) + 1 + 20 ] = ecc_results[j];
}

int maxi_bump(int set[], int character[], int bump_posn)
{
	/* Moves everything up so that a shift or latch can be inserted */
	int i;
	
	for(i = 143; i > bump_posn; i--) {
		set[i] = set[i - 1];
		character[i] = character[i - 1];
	}
}

int maxi_text_process(int mode, unsigned char source[])
{
	/* Format text according to Appendix A */
	
	/* This code doesn't make use of [Lock in C], [Lock in D]
	and [Lock in E] and so is not always the most efficient at
	compressing data, but should suffice for most applications */
	
	int set[144], character[144], i, j, done, count, length, current_set;
	
	length = strlen(source);
	
	if(length > 138) {
		return ERROR_TOO_LONG;
	}
	
	for(i = 0; i < 144; i++) {
		set[i] = -1;
		character[i] = 0;
	}
	
	for (i = 0; i < length; i++) {
		/* Look up characters in table from Appendix A - this gives
		 value and code set for most characters */
		set[i] = maxiCodeSet[source[i]];
		character[i] = maxiSymbolChar[source[i]];
	}
	
	/* If a character can be represented in more than one code set,
	pick which version to use */
	if(set[0] == 0) {
		if(character[0] == 13) {
			character[0] = 0;
		}
		set[0] = 1;
	}

	for(i = 1; i < length; i++) {
		if(set[i] == 0) {
			done = 0;
			/* Special character */
			if(character[i] == 13) {
				/* Carriage Return */
				if(set[i - 1] == 5) {
					character[i] = 13;
					set[i] = 5;
				} else {
					if((i != length - 1) && (set[i + 1] == 5)) {
						character[i] = 13;
						set[i] = 5;
					} else {
						character[i] = 0;
						set[i] = 1;
					}
				}
				done = 1;
			}
						
			if((character[i] == 28) && (done == 0)) {
				/* FS */
				if(set[i - 1] == 5) {
					character[i] = 32;
					set[i] = 5;
				} else {
					set[i] = set[i - 1];
				}
				done = 1;
			}
			
			if((character[i] == 29) && (done == 0)) {
				/* GS */
				if(set[i - 1] == 5) {
					character[i] = 33;
					set[i] = 5;
				} else {
					set[i] = set[i - 1];
				}
				done = 1;
			}

			if((character[i] == 30) && (done == 0)) {
				/* RS */
				if(set[i - 1] == 5) {
					character[i] = 34;
					set[i] = 5;
				} else {
					set[i] = set[i - 1];
				}
				done = 1;
			}
			
			if((character[i] == 32) && (done == 0)) {
				/* Space */
				if(set[i - 1] == 1) {
					character[i] = 32;
					set[i] = 1;
				}
				if(set[i - 1] == 2) {
					character[i] = 47;
					set[i] = 2;
				}
				if(set[i - 1] >= 3) {
					if(i != length - 1) {
						if(set[i + 1] == 1) {
							character[i] = 32;
							set[i] = 1;
						}
						if(set[i + 1] == 2) {
							character[i] = 47;
							set[i] = 2;
						}
						if(set[i + 1] >= 3) {
							character[i] = 59;
							set[i] = set[i - 1];
						}
					} else {
						character[i] = 59;
						set[i] = set[i - 1];
					}
				}
				done = 1;
			}

			if((character[i] == 44) && (done == 0)) {
				/* Comma */
				if(set[i - 1] == 2) {
					character[i] = 48;
					set[i] = 2;
				} else {
					if((i != length - 1) && (set[i + 1] == 2)) {
						character[i] = 48;
						set[i] = 2;
					} else {
						set[i] = 1;
					}
				}
				done = 1;
			}
			
			if((character[i] == 46) && (done == 0)) {
				/* Full Stop */
				if(set[i - 1] == 2) {
					character[i] = 49;
					set[i] = 2;
				} else {
					if((i != length - 1) && (set[i + 1] == 2)) {
						character[i] = 49;
						set[i] = 2;
					} else {
						set[i] = 1;
					}
				}
				done = 1;
			}
			
			if((character[i] == 47) && (done == 0)) {
				/* Slash */
				if(set[i - 1] == 2) {
					character[i] = 50;
					set[i] = 2;
				} else {
					if((i != length - 1) && (set[i + 1] == 2)) {
						character[i] = 50;
						set[i] = 2;
					} else {
						set[i] = 1;
					}
				}
				done = 1;
			}
			
			if((character[i] == 58) && (done == 0)) {
				/* Colon */
				if(set[i - 1] == 2) {
					character[i] = 51;
					set[i] = 2;
				} else {
					if((i != length - 1) && (set[i + 1] == 2)) {
						character[i] = 51;
						set[i] = 2;
					} else {
						set[i] = 1;
					}
				}
				done = 1;
			}
		}
	}
	
	for(i = strlen(source); i < 144; i++) {
		/* Add the padding */
		if(set[length - 1] == 2) {
			set[i] = 2;
		} else {
			set[i] = 1;
		}
		character[i] = 33;
	}

	/* Find candidates for number compression */
	if((mode == 2) || (mode ==3)) { j = 0; } else { j = 9; }
		/* Number compression not allowed in primary message */
	count = 0;
	for(i = j; i < 143; i++) {
		if((set[i] == 1) && ((character[i] >= 48) && (character[i] <= 57))) {
			/* Character is a number */
			count++;
		} else {
			count = 0;
		}
		if(count == 9) {
			/* Nine digits in a row can be compressed */
			set[i] = 6;
			set[i - 1] = 6;
			set[i - 2] = 6;
			set[i - 3] = 6;
			set[i - 4] = 6;
			set[i - 5] = 6;
			set[i - 6] = 6;
			set[i - 7] = 6;
			set[i - 8] = 6;
			count = 0;
		}
	}
	
	/* Add shift and latch characters */
	current_set = 1;
	i = 0;
	do {

		if(set[i] != current_set) {
			switch(set[i]) {
				case 1:
					if(set[i + 1] == 1) {
						if(set[i + 2] == 1) {
							if(set[i + 3] == 1) {
								/* Latch A */
								maxi_bump(set, character, i);
								character[i] = 63;
								current_set = 1;
								length++;
							} else {
								/* 3 Shift A */
								maxi_bump(set, character, i);
								character[i] = 57;
								length++;
								i += 2;
							}
						} else {
							/* 2 Shift A */
							maxi_bump(set, character, i);
							character[i] = 56;
							length++;
							i++;
						}
					} else {
						/* Shift A */
						maxi_bump(set, character, i);
						character[i] = 59;
						length++;
					}
					break;
				case 2:
					if(set[i + 1] == 2) {
						/* Latch B */
						maxi_bump(set, character, i);
						character[i] = 63;
						current_set = 2;
						length++;
					} else {
						/* Shift B */
						maxi_bump(set, character, i);
						character[i] = 59;
						length++;
					}
					break;
				case 3:
					/* Shift C */
					maxi_bump(set, character, i);
					character[i] = 60;
					length++;
					break;
				case 4:
					/* Shift D */
					maxi_bump(set, character, i);
					character[i] = 61;
					length++;
					break;
				case 5:
					/* Shift E */
					maxi_bump(set, character, i);
					character[i] = 62;
					length++;
					break;
				case 6:
					/* Number Compressed */
					/* Do nothing */
					break;
			}
			i++;
		}
		i++;
	} while(i < 145);

	/* Number compression has not been forgotten! - It's handled below */
	i = 0;
	do {
		if (set[i] == 6) {
			/* Number compression */
			char substring[10];
			int value;
			
			for(j = 0; j < 10; j++) {
				substring[j] = character[i + j];
			}
			substring[10] = '\0';
			value = atoi(substring);
			
			character[i] = 31; /* NS */
			character[i + 1] = (value & 0x3f000000) >> 24;
			character[i + 2] = (value & 0xfc0000) >> 18;
			character[i + 3] = (value & 0x3f000) >> 12;
			character[i + 4] = (value & 0xfc0) >> 6;
			character[i + 5] = (value & 0x3f);
			
			i += 6;
			for(j = i; j < 140; j++) {
				set[j] = set[j + 3];
				character[j] = character[j + 3];
			}
			length -= 3;
		} else {
			i++;
		}
	} while (i <= 143);

	if(((mode ==2) || (mode == 3)) && (length > 84)) {
		return ERROR_TOO_LONG;
	}
	
	if(((mode == 4) || (mode == 6)) && (length > 93)) {
		return ERROR_TOO_LONG;
	}
	
	if((mode == 5) && (length > 77)) {
		return ERROR_TOO_LONG;
	}
	
	
	/* Copy the encoded text into the codeword array */
	if((mode == 2) || (mode == 3)) {
		for(i = 0; i < 84; i++) { /* secondary only */
			maxi_codeword[i + 20] = character[i];
		}
	}
	
	if((mode == 4) || (mode == 6)) {
		for(i = 0; i < 9; i++) { /* primary */
			maxi_codeword[i + 1] = character[i];
		}
		for(i = 0; i < 84; i++) { /* secondary */
			maxi_codeword[i + 20] = character[i + 9];
		}
	}
	
	if(mode == 5) {
		for(i = 0; i < 9; i++) { /* primary */
			maxi_codeword[i + 1] = character[i];
		}
		for(i = 0; i < 68; i++) { /* secondary */
			maxi_codeword[i + 20] = character[i + 9];
		}
	}
	
	return 0;
}

void maxi_do_primary_2(char postcode[], int country, int service)
{
	/* Format structured primary for Mode 2 */
	int postcode_length, postcode_num, i;
	
	for(i = 0; i < 10; i++) {
		if((postcode[i] <= '0') || (postcode[i] >= '9')) {
			postcode[i] = '\0';
		}
	}
	
	postcode_length = strlen(postcode);
	postcode_num = atoi(postcode);
	
	maxi_codeword[0] = ((postcode_num & 0x03) << 4) | 2;
	maxi_codeword[1] = ((postcode_num & 0xfc) >> 2);
	maxi_codeword[2] = ((postcode_num & 0x3f00) >> 8);
	maxi_codeword[3] = ((postcode_num & 0xfc000) >> 14);
	maxi_codeword[4] = ((postcode_num & 0x3f00000) >> 20);
	maxi_codeword[5] = ((postcode_num & 0x3c000000) >> 26) | ((postcode_length & 0x3) << 4);
	maxi_codeword[6] = ((postcode_length & 0x3c) >> 2) | ((country & 0x3) << 4);
	maxi_codeword[7] = (country & 0xfc) >> 2;
	maxi_codeword[8] = ((country & 0x300) >> 8) | ((service & 0xf) << 2);
	maxi_codeword[9] = ((service & 0x3f0) >> 4);
}

void maxi_do_primary_3(char postcode[], int country, int service)
{
	/* Format structured primary for Mode 3 */
	int i;

	to_upper(postcode);
	for(i = 0; i < strlen(postcode); i++) {
		if((postcode[i] >= 65) && (postcode[i] <= 90)) {
			/* (Capital) letters shifted to Code Set A values */
			postcode[i] = postcode[i] - 64;
		}
		if(((postcode[i] == 27) || (postcode[i] == 31)) || ((postcode[i] == 33) || (postcode[i] >= 59))) {
			/* Not a valid postcode character */
			postcode[i] = ' ';
		}
		/* Input characters lower than 27 (NUL - SUB) in postcode are
		interpreted as capital letters in Code Set A (e.g. LF becomes 'J') */
	}
	
	maxi_codeword[0] = ((postcode[5] & 0x03) << 4) | 3;
	maxi_codeword[1] = ((postcode[4] & 0x03) << 4) | ((postcode[5] & 0x3c) >> 2);
	maxi_codeword[2] = ((postcode[3] & 0x03) << 4) | ((postcode[4] & 0x3c) >> 2);
	maxi_codeword[3] = ((postcode[2] & 0x03) << 4) | ((postcode[3] & 0x3c) >> 2);
	maxi_codeword[4] = ((postcode[1] & 0x03) << 4) | ((postcode[2] & 0x3c) >> 2);
	maxi_codeword[5] = ((postcode[0] & 0x03) << 4) | ((postcode[1] & 0x3c) >> 2);
	maxi_codeword[6] = ((postcode[0] & 0x3c) >> 2) | ((country & 0x3) << 4);
	maxi_codeword[7] = (country & 0xfc) >> 2;
	maxi_codeword[8] = ((country & 0x300) >> 8) | ((service & 0xf) << 2);
	maxi_codeword[9] = ((service & 0x3f0) >> 4);
}

int maxicode(struct zint_symbol *symbol, unsigned char source[])
{
	int i, j, block, bit, mode, countrycode = 0, service = 0;
	int bit_pattern[7], internal_error = 0, eclen;
	char postcode[12], countrystr[4], servicestr[4];
	mode = symbol->option_1;
	strcpy(postcode, "");
	strcpy(countrystr, "");
	strcpy(servicestr, "");
	
	for(i = 0; i < 145; i++) {
		maxi_codeword[i] = 0;
	}
	
	if(mode == -1) { /* If mode is unspecified */
		if(strlen(symbol->primary) == 0) {
			mode = 4;
		} else {
			mode = 2;
			for(i = 0; i < 10; i++) {
				if((symbol->primary[i] < 48) || (symbol->primary[i] > 57)) {
					mode = 3;
				}
			}
		}
	}
	
	if((mode < 2) || (mode > 6)) { /* Only codes 2 to 6 supported */
		strcpy(symbol->errtxt, "Error: Invalid Maxicode Mode");
		return ERROR_INVALID_OPTION;
	}
	
	if((mode == 2) || (mode == 3)) { /* Modes 2 and 3 need data in symbol->primary */
		if(strlen(symbol->primary) != 15) {
			strcpy(symbol->errtxt, "Error: Invalid Primary String");
			return ERROR_INVALID_DATA;
		}
	
		for(i = 9; i < 15; i++) { /* check that country code and service are numeric */
			if((symbol->primary[i] < 48) || (symbol->primary[i] > 57)) {
				strcpy(symbol->errtxt, "Error: Invalid Primary String");
				return ERROR_INVALID_DATA;
			}
		}
		
		strncpy(postcode, symbol->primary, 9);
		postcode[9] = '\0';
		
		if(mode == 2) {
			for(i = 0; i < 10; i++) {
				if(postcode[i] == ' ') {
					postcode[i] = '\0';
				}
			}
		}

		if(mode == 3) { postcode[6] = '\0'; }
		
		countrystr[0] = symbol->primary[9];
		countrystr[1] = symbol->primary[10];
		countrystr[2] = symbol->primary[11];
		countrystr[3] = '\0';
		
		servicestr[0] = symbol->primary[12];
		servicestr[1] = symbol->primary[13];
		servicestr[2] = symbol->primary[14];
		servicestr[3] = '\0';
		
		countrycode = atoi(countrystr);
		service = atoi(servicestr);

		if(mode == 2) { maxi_do_primary_2(postcode, countrycode, service); }
		if(mode == 3) { maxi_do_primary_3(postcode, countrycode, service); }
	} else {
		maxi_codeword[0] = mode;
	}
	
	i = maxi_text_process(mode, source);
	if(i == ERROR_TOO_LONG ) {
		strcpy(symbol->errtxt, "Error: Input data too long");
		return i;
	}

	/* All the data is sorted - now do error correction */
	
	RS_init = 0;
	codeindex = 0;

	maxi_coeff_init_32();   /* set up error correction constants */
	
	maxi_do_primary_check();  /* always EEC */
	
	if ( mode == 5)
		eclen = 56;   // 68 data codewords , 56 error corrections
	else
		eclen = 40;  // 84 data codewords,  40 error corrections

	maxi_do_secondary_chk_even(eclen/2);  // do error correction of even
	maxi_do_secondary_chk_odd(eclen/2);   // do error correction of odd
	
	/* Copy data into symbol grid */
	for(i = 0; i < 33; i++) {
		for(j = 0; j < 30; j++) {
			symbol->encoded_data[i][j] = '0';
			block = (MaxiGrid[(i * 30) + j] + 5) / 6;
			bit = (MaxiGrid[(i * 30) + j] + 5) % 6;
			
			if(block != 0) {
				
				bit_pattern[0] =  (maxi_codeword[block - 1] & 0x20) >> 5;
				bit_pattern[1] =  (maxi_codeword[block - 1] & 0x10) >> 4;
				bit_pattern[2] =  (maxi_codeword[block - 1] & 0x8) >> 3;
				bit_pattern[3] =  (maxi_codeword[block - 1] & 0x4) >> 2;
				bit_pattern[4] =  (maxi_codeword[block - 1] & 0x2) >> 1;
				bit_pattern[5] =  (maxi_codeword[block - 1] & 0x1);
				
				if(bit_pattern[bit] != 0) {
					symbol->encoded_data[i][j] = '1';
				}
			}
		}
	}

	/* Add orientation markings */
	symbol->encoded_data[0][28] = '1'; // Top right filler
	symbol->encoded_data[0][29] = '1';
	symbol->encoded_data[9][10] = '1'; // Top left marker
	symbol->encoded_data[9][11] = '1';
	symbol->encoded_data[10][11] = '1';
	symbol->encoded_data[15][7] = '1'; // Left hand marker
	symbol->encoded_data[16][8] = '1';
	symbol->encoded_data[16][20] = '1'; // Right hand marker
	symbol->encoded_data[17][20] = '1';
	symbol->encoded_data[22][10] = '1'; // Bottom left marker
	symbol->encoded_data[23][10] = '1';
	symbol->encoded_data[22][17] = '1'; // Bottom right marker
	symbol->encoded_data[23][17] = '1';
	
	symbol->width = 30;
	symbol->rows = 33;

	return internal_error;
}
