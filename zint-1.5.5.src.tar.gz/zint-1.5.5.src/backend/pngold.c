/* png.c - Handles output to PNG file */

/*
    libzint - the open source barcode library
    Copyright (C) 2008 Robin Stuart <zint@hotmail.co.uk>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

/* Any resemblance to the code used by Greg Reolofs' wpng code examples is not
   coincidental. Rather odd use of mainprog_info in this file is due to gradual adaption
   from that code. Read his excellent book "PNG: The Definitive Guide" online at
   http://www.libpng.org/pub/png/book/ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "png.h"        /* libpng header; includes zlib.h and setjmp.h */
#include "common.h"

#define SSET	"0123456789ABCDEF"

struct mainprog_info_type {
    long width;
    long height;
    FILE *outfile;
    jmp_buf jmpbuf;
};
/*
void symbol_dump(struct zint_symbol *symbol)
{
	printf("symbol: %d\n", symbol->symbology);
	printf("height: %d\n", symbol->height);
	printf("whites: %d\n", symbol->whitespace_width);
	printf("border: %d\n", symbol->border_width);
	printf("outopt: %d\n", symbol->output_options);
	printf("fgcols: %s\n", symbol->fgcolour);
	printf("bgcols: %s\n", symbol->bgcolour);
	printf("outfil: %s\n", symbol->outfile);
	printf("pdfsec: %d\n", symbol->pdf_secure);
	printf("pdfcol: %d\n", symbol->pdf_width);
	printf("hrtext: %s\n", symbol->text);
	printf("rows  : %d\n", symbol->rows);
	printf("width : %d\n", symbol->width);
	printf("part  : %d\n", symbol->partial);
	printf("error : %s\n", symbol->errtxt);
}
*/

static void writepng_error_handler(png_structp png_ptr, png_const_charp msg)
{
    struct mainprog_info_type  *graphic;

    fprintf(stderr, "writepng libpng error: %s\n", msg);
    fflush(stderr);

    graphic = png_get_error_ptr(png_ptr);
    if (graphic == NULL) {         /* we are completely hosed now */
        fprintf(stderr,
          "writepng severe error:  jmpbuf not recoverable; terminating.\n");
        fflush(stderr);
        exit(99);
    }
    longjmp(graphic->jmpbuf, 1);
}

int png_plot(struct zint_symbol *symbol)
{
	struct mainprog_info_type wpng_info;
	struct mainprog_info_type *graphic;
	unsigned char outdata[6000];
	png_structp  png_ptr;
	png_infop  info_ptr;
	graphic = &wpng_info;
        long j;
        unsigned long rowbytes;
	unsigned char *image_data;
	int i, k, offset, row, row_binding, errno;
	int fgred, fggrn, fgblu, bgred, bggrn, bgblu;
	
	/* sort out colour options */
	to_upper(symbol->fgcolour);
	to_upper(symbol->bgcolour);
	
	if(strlen(symbol->fgcolour) != 6) {
		strcpy(symbol->errtxt, "error: malformed foreground colour target");
		return ERROR_INVALID_OPTION;
	}
	if(strlen(symbol->bgcolour) != 6) {
		strcpy(symbol->errtxt, "error: malformed background colour target");
		return ERROR_INVALID_OPTION;
	}
	errno = is_sane(SSET, symbol->fgcolour);
	if (errno == ERROR_INVALID_DATA) {
		strcpy(symbol->errtxt, "error: malformed foreground colour target");
		return ERROR_INVALID_OPTION;
	}
	errno = is_sane(SSET, symbol->bgcolour);
	if (errno == ERROR_INVALID_DATA) {
		strcpy(symbol->errtxt, "error: malformed background colour target");
		return ERROR_INVALID_OPTION;
	}
	
	fgred = (16 * ctoi(symbol->fgcolour[0])) + ctoi(symbol->fgcolour[1]);
	fggrn = (16 * ctoi(symbol->fgcolour[2])) + ctoi(symbol->fgcolour[3]);
	fgblu = (16 * ctoi(symbol->fgcolour[4])) + ctoi(symbol->fgcolour[5]);
	bgred = (16 * ctoi(symbol->bgcolour[0])) + ctoi(symbol->bgcolour[1]);
	bggrn = (16 * ctoi(symbol->bgcolour[2])) + ctoi(symbol->bgcolour[3]);
	bgblu = (16 * ctoi(symbol->bgcolour[4])) + ctoi(symbol->bgcolour[5]);
	
	/* x-dimension is equivalent to 2 pixels so multiply everything by 2 */
	
	/* calculate graphic width and height */
	graphic->width = 2 * (symbol->width + (symbol->border_width * 2) + (symbol->whitespace_width * 2));
	row_binding = 0;

	switch(symbol->symbology) {
		case BARCODE_AUSPOST:
		case BARCODE_AUSROUTE:
		case BARCODE_AUSREPLY:
		case BARCODE_AUSREDIRECT:
		case BARCODE_RM4SCC:
		case BARCODE_ONECODE:
		case BARCODE_MICROPDF417:
			graphic->height = (4 * symbol->rows) + (4 * symbol->border_width);
			break;
		case BARCODE_PDF417:
		case BARCODE_PDF417TRUNC:
			graphic->height = (6 * symbol->rows) + (4 * symbol->border_width);
			break;
		case BARCODE_POSTNET:
		case BARCODE_PLANET:
			graphic->height = (10 * symbol->rows) + (4 * symbol->border_width);
			break;
		case BARCODE_DATAMATRIX:
		case BARCODE_QRCODE:
			graphic->height = (2 * symbol->rows) + (4 * symbol->border_width);
			break;
		case BARCODE_CODE16K:
			graphic->height = (16 * symbol->rows) + (4 * symbol->border_width);
			break;
		case BARCODE_MAXICODE:
			/* Maxicode cannot be displayed in a PNG file (yet!) */
			strcpy(symbol->errtxt, "error: Maxicode cannot be displayed in a PNG file");
			return ERROR_INVALID_OPTION;
			break;
		case BARCODE_RSS14STACK:
		case BARCODE_RSS14STACK_OMNI:
		case BARCODE_RSS_EXPSTACK:
			/* RSS also cannot be displayed properly yet */
			strcpy(symbol->errtxt, "error: GS1 DataBar not supported by PNG output");
			return ERROR_INVALID_OPTION;
			break;
		default:
			if(symbol->height == 0) { graphic->height = 100; } else
			{ graphic->height = (2 * symbol->height) + (symbol->border_width * 4); }
			if((symbol->rows > 1) && ((symbol->output_options == BARCODE_BIND) || (symbol->output_options == BARCODE_BOX))) {
				row_binding = 1;
			}
			break;
	}

	if(symbol->symbology == BARCODE_CODE16K) {
		row_binding = 1;
	}
	
	/* Open output file in binary mode */
	if (!(graphic->outfile = fopen(symbol->outfile, "wb"))) {
		strcpy(symbol->errtxt, "error: can't open output file");
		return ERROR_FILE_ACCESS;
	}
	
	/* Set up error handling routine as proc() above */
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, graphic,
		writepng_error_handler, NULL);
	if (!png_ptr) {
		strcpy(symbol->errtxt, "error: out of memory");
		return ERROR_MEMORY;
	}

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) {
		png_destroy_write_struct(&png_ptr, NULL);
		strcpy(symbol->errtxt, "error: out of memory");
		return ERROR_MEMORY;
	}

	/* catch jumping here */
	if (setjmp(graphic->jmpbuf)) {
		png_destroy_write_struct(&png_ptr, &info_ptr);
		strcpy(symbol->errtxt, "error: libpng error occurred");
		return ERROR_MEMORY;
	}

	/* open output file with libpng */
	png_init_io(png_ptr, graphic->outfile);

	/* set compression */
	png_set_compression_level(png_ptr, Z_BEST_COMPRESSION);

	/* set Header block */
	png_set_IHDR(png_ptr, info_ptr, graphic->width, graphic->height,
		8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
		PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);

	/* write all chunks up to (but not including) first IDAT */
	png_write_info(png_ptr, info_ptr);

	/* set up the transformations:  for now, just pack low-bit-depth pixels
	   into bytes (one, two or four pixels per byte) */
	png_set_packing(png_ptr);

	/* set rowbytes - depends on picture depth */
	rowbytes = wpng_info.width * 3;

	/* Pixel Plotting */
	offset = (2 * symbol->border_width) + (2 * symbol->whitespace_width);
	for (j = 0;  j < graphic->height;  j++) {

		/* top border */
		if (j < (2 * symbol->border_width)) {
			if ((symbol->output_options == BARCODE_BOX) || (symbol->output_options == BARCODE_BIND)) {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = fgred;
					outdata[i + 1] = fggrn;
					outdata[i + 2] = fgblu;
				}
			} else {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}
			}
		}

		/* middle section */
		if ((j >= (2 * symbol->border_width)) && (j < (graphic->height - (2 * symbol->border_width)))) {
			for(i = 0; i < (graphic->width * 3); i+= 3) {
				k = (i / 3);

				/* left hand border */
				if(k < (2 * symbol->border_width)) {
					if(symbol->output_options == BARCODE_BOX) {
						outdata[i] = fgred;
						outdata[i + 1] = fggrn;
						outdata[i + 2] = fgblu;
					} else {
						outdata[i] = bgred;
						outdata[i + 1] = bggrn;
						outdata[i + 2] = bgblu;
					}
				}

				/* left whitespace */
				if((k >= (2 * symbol->border_width)) && (k < ((2 * symbol->border_width) + (2 * symbol->whitespace_width)))) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}

				/* the symbol area */
				if((k >= ((2 * symbol->border_width) + (2 * symbol->whitespace_width))) && (k < (graphic->width - ((2 * symbol->border_width) + (2 * symbol->whitespace_width))))) {
					int row_height;

					row_height = (graphic->height - (2 * symbol->border_width)) / symbol->rows;
					row =  (j - (2 * symbol->border_width)) / row_height;
					switch(symbol->encoded_data[row][(k - offset) / 2])
					{
						case '1':
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
							break;
						case 'o':
							outdata[i] = 255;
							outdata[i + 1] = 155;
							outdata[i + 2] = 0;
							break;
						case 'u':
							outdata[i] = 0;
							outdata[i + 1] = 0;
							outdata[i + 2] = 255;
							break;
						default:
							outdata[i] = bgred;
							outdata[i + 1] = bggrn;
							outdata[i + 2] = bgblu;
							break;

					}

					/* row binding */
					if(row_binding) {
						if (j == (((row * row_height) + (2 * symbol->border_width)) - 2)) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
						if (j == (((row * row_height) + (2 * symbol->border_width)) - 1)) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
						if (j == (row * row_height) + (2 * symbol->border_width)) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
						if (j == (((row * row_height) + (2 * symbol->border_width)) + 1)) {
							outdata[i] = fgred;
							outdata[i + 1] = fggrn;
							outdata[i + 2] = fgblu;
						}
					}
				}

				/* right whitespace */
				if((k >= (graphic->width - ((2 *symbol->border_width) + (2 * symbol->whitespace_width)))) && (k < (graphic->width - (2 * symbol->border_width)))) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}

				/* right hand border */
				if(k >= (graphic->width - (2 * symbol->border_width))) {
					if(symbol->output_options == BARCODE_BOX) {
						outdata[i] = fgred;
						outdata[i + 1] = fggrn;
						outdata[i + 2] = fgblu;
					} else {
						outdata[i] = bgred;
						outdata[i + 1] = bggrn;
						outdata[i + 2] = bgblu;
					}
				}
			}
			/* diagnostic
			printf("row %d ", row);
			for(i=0; i < symbol->width; i++) {
				printf("%c", symbol->encoded_data[row][i]);
			}
			printf("\n");
			*/
		}

		/* bottom border */
		if (j >= (graphic->height - (2 * symbol->border_width))) {
			if ((symbol->output_options == BARCODE_BOX) || (symbol->output_options == BARCODE_BIND)) {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = fgred;
					outdata[i + 1] = fggrn;
					outdata[i + 2] = fgblu;
				}
			} else {
				for(i = 0; i < (graphic->width * 3); i+=3) {
					outdata[i] = bgred;
					outdata[i + 1] = bggrn;
					outdata[i + 2] = bgblu;
				}
			}
		}

		/* write row contents to file */
		image_data = outdata;
		png_write_row(png_ptr, image_data);
	}

	/* End the file */
	png_write_end(png_ptr, NULL);

	/* make sure we have disengaged */
	if (png_ptr && info_ptr) png_destroy_write_struct(&png_ptr, &info_ptr);
	fclose(wpng_info.outfile);

	return 0;
}
