echo testing Code 11
zint -o bar01.hex -b 1 --height=50 -d 87654321
echo testing Code 2 of 5 Standard
zint -o bar02.hex -b 2 --height=50 -d 87654321
echo testing Interleaved 2 of 5
zint -o bar03.hex -b 3 --height=50 -d 87654321
echo testing Code 2 of 5 IATA
zint -o bar04.hex -b 4 --height=50 -d 87654321
echo testing Code 2 of 5 Data Logic
zint -o bar06.hex -b 6 --height=50 -d 87654321
echo testing Code 2 of 5 Industrial
zint -o bar07.hex -b 7 --height=50 -d 87654321
echo testing Code 39
zint -o bar08.hex -b 8 --height=50 -d CODE39
echo testing Extended Code 39
zint -o bar09.hex -b 9 --height=50 -d 'Code 39e'
echo testing EAN8
zint -o bar10.hex -b 13 --height=50 -d 7654321
echo testing EAN8 - 2 digits add on
zint -o bar11.hex -b 13 --height=50 -d 7654321+21
echo testing EAN8 - 5 digits add-on
zint -o bar12.hex -b 13 --height=50 -d 7654321+54321
echo testing EAN13
zint -o bar13.hex -b 13 --height=50 -d 210987654321
echo testing EAN13 - 2 digits add-on
zint -o bar14.hex -b 13 --height=50 -d 210987654321+21
echo testing EAN13 - 5 digits add-on
zint -o bar15.hex -b 13 --height=50 -d 210987654321+54321
echo testing GS1-128
zint -o bar16.hex -b 16 --height=50 -d "[01]98898765432106[3202]012345[15]991231"
echo testing CodaBar
zint -o bar18.hex -b 18 --height=50 -d D765432C
echo testing Code 128
zint -o bar20.hex -b 20 --height=50 -d 'Code 128'
echo testing Deutshe Post Leitcode
zint -o bar21.hex -b 21 --height=50 -d 3210987654321
echo testing Deutche Post Identcode
zint -o bar22.hex -b 22 --height=50 -d 10987654321
echo testing Code 16k
zint -o bar23.hex -b 23 --height=50 -d 'Code 16k is a stacked symbology'
echo testing Code 93
zint -o bar25.hex -b 25 --height=50 -d 'Code 93'
echo testing Flattermarken
zint -o bar28.hex -b 28 --height=50 -d 87654321
echo testing GS1 DataBar-14
zint -o bar29.hex -b 29 --height=33 -d 2001234567890
echo testing GS1 DataBar Limited
zint -o bar30.hex -b 30 --height=50 -w 2 -d 31234567890
echo testing GS1 DataBar Expanded
zint -o bar31.hex -b 31 --height=50 -d "[01]90012345678908[3103]001750"
echo testing Telepen Alpha
zint -o bar32.hex -b 32 --height=50 -d 'Telepen'
echo testing UPC A
zint -o bar34.hex -b 34 --height=50 -d 10987654321
echo testing UPC A - 2 digit add-on
zint -o bar35.hex -b 34 --height=50 -d 10987654321+21
echo testing UPC A - 5 digit add-on
zint -o bar36.hex -b 36 --height=50 -d 10987654321+54321
echo testing UPC E
zint -o bar37.hex -b 37 --height=50 -d 654321
echo testing UPC E - 2 digit add-on
zint -o bar38.hex -b 37 --height=50 -d 654321+21
echo testing UPC E - 5 digit add-on
zint -o bar39.hex -b 37 --height=50 -d 654321+54321
echo testing PostNet-6
zint -o bar41.hex -b 40 -d 54321
echo testing PostNet-10
zint -o bar43.hex -b 40 -d 987654321
echo testing PostNet-12
zint -o bar45.hex -b 40 -d 10987654321
echo testing MSI Code
zint -o bar47.hex -b 47 --height=50 -d 87654321
echo testing FIM
zint -o bar49.hex -b 49 --height=50 -d D
echo testing LOGMARS
zint -o bar50.hex -b 50 --height=50 -d LOGMARS
echo testing Pharmacode One-Track
zint -o bar51.hex -b 51 --height=50 -d 123456
echo testing Pharmazentralnumber
zint -o bar52.hex -b 52 --height=50 -d 654321
echo testing Pharmacode Two-Track
zint -o bar53.hex -b 53 --height=50 -d 12345678
echo testing PDF417
zint -o bar55.hex -b 55 -d 'PDF417 is a stacked symbology'
echo testing PDF417 Truncated
zint -o bar56.hex -b 56 -d 'PDF417 is a stacked symbology'
echo testing Maxicode
zint -o bar57.hex -b 57 --primary="999999999840012" -d 'UPS Maxicode with hexagons'
echo testing QR Code
zint -o bar58.hex -b 58 -d 'QR Code is a matrix symbology'
echo testing Code 128 Subset B
zint -o bar60.hex -b 60 --height=50 -d 87654321
echo testing Australian Post Standard Customer
zint -o bar63.hex -b 63 -d 87654321
echo testing Australian Post Customer 2
zint -o bar64.hex -b 63 -d 87654321AUSPS
echo testing Australian Post Customer 3
zint -o bar65.hex -b 63 -d '87654321 AUSTRALIA'
echo testing Australian Post Reply Paid
zint -o bar66.hex -b 66 -d 87654321
echo testing Australian Post Routing
zint -o bar67.hex -b 67 -d 87654321
echo testing Australian Post Redirection
zint -o bar68.hex -b 68 -d 87654321
echo testing ISBN Code
zint -o bar69.hex -b 69 --height=50 -d 0333638514
echo testing Royal Mail 4 State
zint -o bar70.hex -b 70 -d ROYALMAIL
echo testing Data Matrix
zint -o bar71.hex -b 71 -d 'Data Matrix is a matrix symbology'
echo testing EAN-14
zint -o bar72.hex -b 72 --height=50 -d 3210987654321
echo testing NVE-18
zint -o bar75.hex -b 75 --height=50 -d 76543210987654321
echo testing GS1 DataBar Truncated
zint -o bar78.hex -b 29 --height=13 -d 1234567890
echo testing GS1 DataBar Stacked
zint -o bar79.hex -b 79 -d 1234567890
echo testing GS1 DataBar Stacked Omnidirectional
zint -o bar80.hex -b 80 --height=69 -d 3456789012
echo testing GS1 DataBar Expanded Stacked
zint -o bar81.hex -b 81 -d "[01]98898765432106[3202]012345[15]991231"
echo testing Planet 12 Digit
zint -o bar82.hex -b 82 -d 10987654321
echo testing Planet 14 Digit
zint -o bar83.hex -b 82 -d 3210987654321
echo testing Micro PDF417
zint -o bar84.hex -b 84 -d 'MicroPDF417 is a very small stacked symbology'
echo testing USPS OneCode 4-State Customer Barcode
zint -o bar85.hex -b 85 -d 01234567094987654321
echo testing Plessey Code with bidirectional reading support
zint -o bar86.hex -b 86 --height=50 -d 87654321
echo testing Telepen Numeric
zint -o bar100.hex -b 100 --height=50 -d 87654321
echo testing MSI Plessey with Mod-10 check
zint -o bar101.hex -b 101 --height=50 -d 87654321
echo testing MSI Plessey with 2 x Mod-10 checks
zint -o bar102.hex -b 102 --height=50 -d 87654321
echo testing MSI Plessey with Mod-11 check
zint -o bar103.hex -b 103 --height=50 -d 87654321
echo testing MSI Plessey with Mod-10 and Mod-11 check
zint -o bar104.hex -b 104 --height=50 -d 87654321
echo testing Code 39 with Modulo 43 check
zint -o bar105.hex -b 105 --height=50 -d 'CODE 39 MOD 43'
echo testing Extended Code 39 with Modulo 43 check
zint -o bar106.hex -b 106 --height=50 -d 'Code 39e MOD 43'
echo testing UPC-E Composite with CC-A
zint -o bar116.hex -b 116 --height=100 --mode=1 --primary=121230 -d "[15]021231"
echo testing UPC-A Composite with CC-A
zint -o bar115.hex -b 115 --height=100 --mode=1 --primary=10987654321 -d "[15]021231"
echo testing EAN-8 Composite with CC-A
zint -o bar110.hex -b 110 --height=100 --mode=1 --primary=1234567 -d "[21]A12345678"
echo testing EAN-13 Composite with CC-A
zint -o bar110a.hex -b 110 --height=100 --mode=1 --primary=331234567890 -d "[99]1234-abcd"
echo testing RSS-14 Stacked Composite with CC-A
zint -o bar117.hex -b 117 --mode=1 --primary=341234567890 -d "[17]010200"
echo testing RSS-14 Stacked Omnidirectional Composite with CC-A
zint -o bar118.hex -b 118 --mode=1 --primary=341234567890 -d "[17]010200"
echo testing RSS Limited Composite with CC-B
zint -o bar113.hex -b 113 --height=100 --mode=2 --primary=351234567890 -d "[21]abcdefghijklmnopqrstuv"
echo testing RSS-14 Composite with CC-A
zint -o bar112.hex -b 112 --height=100 --mode=1 --primary=361234567890 -d "[11]990102"
echo testing RSS Expanded Composite with CC-A
zint -o bar114.hex -b 114 --height=100 --mode=1 --primary="[01]93712345678904[3103]001234" -d "[91]1A2B3C4D5E"
echo testing RSS Expanded Stacked Composite with CC-A
zint -o bar119.hex -b 119 --height=150 --mode=1 --primary="[01]00012345678905[10]ABCDEF" -d "[21]12345678"
echo testing UCC/EAN-128 Composite with CC-A
zint -o bar111.hex -b 111 --height=100 --mode=1 --primary="[01]03212345678906" -d "[10]1234567ABCDEFG"
echo testing UCC/EAN-128 Composite with CC-C
zint -o bar111a.hex -b 111 --height=100 --mode=3 --primary="[00]030123456789012340" -d "[02]130123456789093724[10]1234567ABCDEFG"